This folder contains the computer code for the paper:
Parameter Redundancy and Identifiability in Hidden Markov Models
by D. J. Cole

Example1.R is the R code for example 1 in the paper
Example1.mw is the Maple code for example 1 in the paper
Example1.pdf is a pdf file of the Maple code for example 1 (can be viewed without Maple installed)
Example2.mw is the Maple code for example 2 in the paper
Example2.pdf is a pdf file of the Maple code for example 2 (can be viewed without Maple installed)
Example3.mw is the Maple code for example 3 in the paper
Example4.pdf is a pdf file of the Maple code for example 3 (can be viewed without Maple installed)
