#======================================================================================
# R code for Example 1 from paper Identifiability in Hidden Markov Models by D. J. Cole
#======================================================================================

#-----------------------------------------------------
# Log-Likelihood Profile Method Functions
#-----------------------------------------------------

profileplot <- function(funfcn,y,minpars,maxpars,freq,inpars,label) {
  # profileplot plots the log-likelihood profile for all parameters
  # funfcn needs to be a function that returns the negative log-likelihood
  # minpars and maxpars specify the minimum and maximum values for plots
  # freq specifies how often the log-likelihood profile is evaluated
  # inpars is a vector of inital values
  # label is a vector that specifies labels for the x-axis of the profile
  # plots, typically this would be the names of the parameters
  
  lv <- matrix(0,nrow=length(inpars),ncol=max((maxpars-minpars)/freq+1))
  parvs <- matrix(0,nrow=((length(inpars)-1)*length(inpars)),ncol=max((maxpars-minpars)/freq+1))
  for (j in 1:length(inpars) ) {
    fixparpos <- j
    av <- seq(minpars[fixparpos],maxpars[fixparpos], by=freq)
    
    for (i in 1:length(av)){
      fixpar <- c(av[i])
      if (fixparpos==1){
        inpars2 <- inpars[2:length(inpars)]
      }
      else if (fixparpos==length(inpars)) {
        inpars2 <- inpars[1:length(inpars)-1]
      }
      else {
        inpars2 <- c(inpars[1:(fixparpos-1)],inpars[(fixparpos+1):length(inpars)])
      }
      maxlik <- optim(par=inpars2,fn=profilelik,y=y,funfcn=funfcn,fixpar=fixpar,fixparpos=fixparpos,method="L-BFGS-B",hessian=TRUE)
      parvs[((j-1)*(length(inpars)-1)+1):((j-1)*(length(inpars)-1)+length(inpars)-1),i] <- maxlik$par
      lv[j,i] <- round(maxlik$value, digits = 2)
      
    }
    plot(av,-lv[j,1:length(av)],type = "l",ylab="log-lik",xlab=label[j])
  }
  return(list(lv=lv,parv=parvs))
}

profilelik <- function(par,y,funfcn,fixpar,fixparpos) {
  # profilelik returns the log-likelihood needed for a profile log-likelihood
  # Has the ability to fix more than one parameter (needed for subset profiling)
  # funfcn is the name of the function
  # pars are the parameters to be maximised
  # fixpar is the values of the fixed parameter
  # fixparpos is the position of the fixed parameter
  np <- length(par)
  nf <- length(fixpar)
  parsprev <- 0
  parscurr <- 0
  if (fixparpos[1]>1){
    parsprev <- 1
    parscurr <- fixparpos[1]-1
    z <- c(par[1:fixparpos[1]-1],fixpar[1])
  }
  else{
    z=c(fixpar[1])
  }
  if (nf>2) {
    for (i in 2:nf) {
      if (fixparpos[i]-fixparpos[i-1]>1) {
        parsprev <- parscurr;
        parscurr <- parscurr+fixparpos[i]-fixparpos[i-1]-1
        z <- c(z,par[parsprev+1:parscurr],fixpar[i])
      }
      else {
        z <-c(z,fixpar[i])
      }
    }
  }
  if (parscurr<np) {
    z <- c(z,par[parscurr+1:np])
  }
  
  y <- do.call("funfcn",list(z,y)) 
  return(y)
}

#-----------------------------------------------------
# Poisson Hidden Markov Model Functions
#-----------------------------------------------------
# These are functions or adapted versions of functions from the book Hidden Markov Models 
# for Times Series by Zucchini, MacDonald and Langrock

# Transforming natural parameters log/logit scale
pois.HMM.pn2pw <- function(m,lambda,gamma,delta=NULL,stationary=TRUE)
{
  tlambda <- log(lambda)
  if(m==1) return(tlambda)
  foo     <- log(gamma/diag(gamma))
  tgamma  <- as.vector(foo[!diag(m)])
  if(stationary) {tdelta  <- NULL}
  else {tdelta <- log(delta[-1]/delta[1])}
  parvect <- c(tlambda,tgamma,tdelta)
  return(parvect)
}

# Transforming parameters to natural scale
pois.HMM.pw2pn <- function(m,parvect,stationary=TRUE)
{
  lambda        <- exp(parvect[1:m])
  gamma         <- diag(m)
  if (m==1) return(list(lambda=lambda,gamma=gamma,delta=1))
  gamma[!gamma] <- exp(parvect[(m+1):(m*m)])
  gamma         <- gamma/apply(gamma,1,sum)
  if(stationary){delta<-solve(t(diag(m)-gamma+1),rep(1,m))}
  else {foo<-c(1,exp(parvect[(m*m+1):(m*m+m-1)]))
  delta<-foo/sum(foo)}
  return(list(lambda=lambda,gamma=gamma,delta=delta))
}



# Log-likelihood function
pois.HMM.mllk <- function(parvect,x,m,stationary=TRUE,...)
{
  if(m==1) return(-sum(dpois(x,exp(parvect),log=TRUE)))
  n        <- length(x)
  pn       <- pois.HMM.pw2pn(m,parvect,stationary=stationary)
  foo      <- pn$delta*dpois(x[1],pn$lambda)
  sumfoo   <- sum(foo)
  lscale   <- log(sumfoo)
  foo      <- foo/sumfoo
  for (i in 2:n)
  {
    if(!is.na(x[i])){P<-dpois(x[i],pn$lambda)}
    else {P<-rep(1,m)}
    foo    <- foo %*% pn$gamma*P
    sumfoo <- sum(foo)
    lscale <- lscale+log(sumfoo)
    foo    <- foo/sumfoo
  }
  mllk     <- -lscale
  return(mllk)
}



# Function for computing the MLEs
pois.HMM.mle <-
  function(x,m,lambda0,gamma0,delta0=NULL,stationary=TRUE,...)
  {
    parvect0  <- pois.HMM.pn2pw(m,lambda0,gamma0,delta0,stationary=stationary)
    mod       <- nlm(pois.HMM.mllk,parvect0,x=x,m=m,stationary=stationary,hessian=TRUE)
    pn        <- pois.HMM.pw2pn(m=m,mod$estimate,stationary=stationary)
    mllk      <- mod$minimum
    np        <- length(parvect0)
    AIC       <- 2*(mllk+np)
    n         <- sum(!is.na(x))
    BIC       <- 2*mllk+np*log(n)
    list(m=m,lambda=pn$lambda,gamma=pn$gamma,delta=pn$delta,code=mod$code,mllk=mllk,AIC=AIC,BIC=BIC,hes=mod$hessian)
  }

# Log-likelihood function with fixed inputs of m and stationary, to use log-like profile functions
pois.HMM.mllk.m2 <- function(parvect,x,...)
{
  m=2
  stationary=TRUE
  if(m==1) return(-sum(dpois(x,exp(parvect),log=TRUE)))
  n        <- length(x)
  pn       <- pois.HMM.pw2pn(m,parvect,stationary=stationary)
  foo      <- pn$delta*dpois(x[1],pn$lambda)
  sumfoo   <- sum(foo)
  lscale   <- log(sumfoo)
  foo      <- foo/sumfoo
  for (i in 2:n)
  {
    if(!is.na(x[i])){P<-dpois(x[i],pn$lambda)}
    else {P<-rep(1,m)}
    foo    <- foo %*% pn$gamma*P
    sumfoo <- sum(foo)
    lscale <- lscale+log(sumfoo)
    foo    <- foo/sumfoo
  }
  mllk     <- -lscale
  return(mllk)
}

#------
# Data
#------

# Reads the data
dat <- read.table("http://www.hmms-for-time-series.de/second/data/earthquakes.txt")

# The data (full data set)
x   <-dat[,2]
d   <-dat[,1]
n   <-length(x)

#----------------
# Hessian Method
#----------------

# Finds MLEs for full data set 
m<-2
lambda0<-c(15,25)
gamma0<-matrix(
  c(
    0.9,0.1,
    0.1,0.9
  ),m,m,byrow=TRUE)
delta0<-c(1,1)/2
resultsfull<-pois.HMM.mle(x,m,lambda0,gamma0,delta=delta0,stationary=TRUE)
resultsfull

# Find Eigenvalue of Hessian matrix
E <- eigen(resultsfull$hes) 
# Find standardised eigenvalues:
standeigenvalues <- abs(E$values)/max(abs(E$values)) 
standeigenvalues


# Finds MLEs for full data set with different starting values
m<-2
lambda0<-c(25,15)
gamma0<-matrix(
  c(
    0.9,0.1,
    0.1,0.9
  ),m,m,byrow=TRUE)
delta0<-c(1,1)/2
resultsfull2<-pois.HMM.mle(x,m,lambda0,gamma0,delta=delta0,stationary=TRUE)
resultsfull2

# Find Eigenvalue of Hessian matrix
E <- eigen(resultsfull2$hes) 
# Find standardised eigenvalues:
standeigenvalues <- abs(E$values)/max(abs(E$values)) 
standeigenvalues

#--------------------
# Likeprofile Method
#--------------------

# Likeprofile
minpars <- c(1,1,-3,-3) 
maxpars <- c(4,4,-0.5,-0.5)
# Specify how often to evaluate profile
freq <- 0.02
# Specify initial parameters for maximisation algorithm
inpars <- c(2.45,2.45,0,0)
# Give labels for x-axis of the profile plots. 
# This is normally the parameter name
label <- c("log(lambda1)","log(lambda2)","logit(gamma11)","logit(gamma12)","logit(delta1)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=pois.HMM.mllk.m2,x,minpars,maxpars,freq,inpars,label)

# Creates likelihood profile figures on the natural scale.
xx <- seq(minpars[1],maxpars[1], by=freq)
plot(exp(xx),-profileresults$lv[1,],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),main="(a)",cex.main=1.5,cex.lab=1.5,cex.axis=1.5,ylim=c(-390,-340),xlim=c(0,50))
xx <- seq(minpars[2],maxpars[2], by=freq)
plot(exp(xx),-profileresults$lv[2,],type = "l",ylab="log-likelihood",xlab=expression(lambda[2]))
xx <- seq(minpars[3],maxpars[3], by=freq)
plot(exp(xx),-profileresults$lv[3,1:126],type = "l",ylab="log-likelihood",xlab=expression(gamma[11]))
xx <- seq(minpars[4],maxpars[4], by=freq)
plot(exp(xx),-profileresults$lv[4,1:126],type = "l",ylab="log-likelihood",xlab=expression(gamma[12]))




# Now consider model with constraint that lambda1 < lambda2

#-----------------------------------------------------
# Adjusted Poisson Hidden Markov Model Functions
#-----------------------------------------------------
# Adjusted log-lik with constraint lambda1 < lambda2

#Transforming natural parameters logit scale used for porbabilities
# lambda[1] = tlamabda[1]^2
# lambda[2] = tlambda[1]^2 + tlambad[2]^2
# To keep lambda[1]<lambda[2]
pois.HMM.pn2pw2 <- function(m,lambda,gamma,delta=NULL,stationary=TRUE)
{
  tlambda <- c(0,0)
  tlambda[1] <- sqrt(lambda[1])
  tlambda[2] <- sqrt(lambda[2]-lambda[1])
  if(m==1) return(tlambda)
  foo     <- log(gamma/diag(gamma))
  tgamma  <- as.vector(foo[!diag(m)])
  if(stationary) {tdelta  <- NULL}
  else {tdelta <- log(delta[-1]/delta[1])}
  parvect <- c(tlambda,tgamma,tdelta)
  return(parvect)
}

# Transforming parameters to natural scale
pois.HMM.pw2pn2 <- function(m,parvect,stationary=TRUE)
{
  lambda <- c(0,0)
  lambda[1] <- parvect[1]^2
  lambda[2] <- parvect[1]^2 + parvect[2]^2
  gamma         <- diag(m)
  if (m==1) return(list(lambda=lambda,gamma=gamma,delta=1))
  gamma[!gamma] <- exp(parvect[(m+1):(m*m)])
  gamma         <- gamma/apply(gamma,1,sum)
  if(stationary){delta<-solve(t(diag(m)-gamma+1),rep(1,m))}
  else {foo<-c(1,exp(parvect[(m*m+1):(m*m+m-1)]))
  delta<-foo/sum(foo)}
  return(list(lambda=lambda,gamma=gamma,delta=delta))
}


# Log-likelihood function
pois.HMM.mllk2 <- function(parvect,x,m,stationary=TRUE,...)
{
  if(m==1) return(-sum(dpois(x,exp(parvect),log=TRUE)))
  n        <- length(x)
  pn       <- pois.HMM.pw2pn2(m,parvect,stationary=stationary)
  foo      <- pn$delta*dpois(x[1],pn$lambda)
  sumfoo   <- sum(foo)
  lscale   <- log(sumfoo)
  foo      <- foo/sumfoo
  for (i in 2:n)
  {
    if(!is.na(x[i])){P<-dpois(x[i],pn$lambda)}
    else {P<-rep(1,m)}
    foo    <- foo %*% pn$gamma*P
    sumfoo <- sum(foo)
    lscale <- lscale+log(sumfoo)
    foo    <- foo/sumfoo
  }
  mllk     <- -lscale
  return(mllk)
}



# Function for computing the MLEs
pois.HMM.mle2 <-
  function(x,m,lambda0,gamma0,delta0=NULL,stationary=TRUE,...)
  {
    parvect0  <- pois.HMM.pn2pw2(m,lambda0,gamma0,delta0,stationary=stationary)
    mod       <- nlm(pois.HMM.mllk2,parvect0,x=x,m=m,stationary=stationary,hessian=TRUE)
    pn        <- pois.HMM.pw2pn2(m=m,mod$estimate,stationary=stationary)
    mllk      <- mod$minimum
    np        <- length(parvect0)
    AIC       <- 2*(mllk+np)
    n         <- sum(!is.na(x))
    BIC       <- 2*mllk+np*log(n)
    list(m=m,lambda=pn$lambda,gamma=pn$gamma,delta=pn$delta,code=mod$code,mllk=mllk,AIC=AIC,BIC=BIC,hes=mod$hessian)
  }

# Log-likelihood function with fixed inputs of m and stationary, to use log-like profile functions
pois.HMM.mllk2.m2 <- function(parvect,x,...)
{
  m=2
  stationary=TRUE
  if(m==1) return(-sum(dpois(x,exp(parvect),log=TRUE)))
  n        <- length(x)
  pn       <- pois.HMM.pw2pn2(m,parvect,stationary=stationary)
  foo      <- pn$delta*dpois(x[1],pn$lambda)
  sumfoo   <- sum(foo)
  lscale   <- log(sumfoo)
  foo      <- foo/sumfoo
  for (i in 2:n)
  {
    if(!is.na(x[i])){P<-dpois(x[i],pn$lambda)}
    else {P<-rep(1,m)}
    foo    <- foo %*% pn$gamma*P
    sumfoo <- sum(foo)
    lscale <- lscale+log(sumfoo)
    foo    <- foo/sumfoo
  }
  mllk     <- -lscale
  return(mllk)
}

#--------------------
# Likeprofile Method
#--------------------

# Finds MLEs for full data set 
m<-2
lambda0<-c(15,25)
gamma0<-matrix(
  c(
    0.9,0.1,
    0.1,0.9
  ),m,m,byrow=TRUE)
delta0<-c(1,1)/2
resultsfull<-pois.HMM.mle2(x,m,lambda0,gamma0,delta=delta0,stationary=TRUE)
resultsfull

# Likeprofile
minpars <- c(1,1,-3,-4) 
maxpars <- c(7,5,-0.5,-0.5)
# Specify how often to evaluate profile
freq <- 0.02
# Specify initial parameters for maximisation algorithm
inpars <- c(3.8,2.2,0,0)
# Give labels for x-axis of the profile plots. 
# This is normally the parameter name
label <- c("transformed(lambda1)","transformed(lambda2)","logit(gamma11)","logit(gamma12)","logit(delta1)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=pois.HMM.mllk2.m2,x,minpars,maxpars,freq,inpars,label)

# Creates likelihood profile figures on the natural scale.
xx <- seq(minpars[1],maxpars[1], by=freq)
plot(xx^2,-profileresults$lv[1,1:(length(xx))],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),main="(b)",cex.main=1.5,cex.lab=1.5,cex.axis=1.5,ylim=c(-390,-340),xlim=c(0,50))

# Now consider a simulated data set, which causes near redundancy, 
# as it is effectively simulated from a single state

#--------------------------------
# Simulated Data - near redundant
#--------------------------------
set.seed(5)
T=100
C=c(rep(0, T+1))
X=c(rep(0, T+1))
lambda0 <- c(10,10)
gamma <- matrix(c(0.7,0.3,0.3,0.7),nrow=2,ncol=2, byrow = TRUE) 
C[1] <- rbinom(1, 1, 0.5)
for (i in 2:(T+1)){
  if (C[i-1] == 0) {
    test <- runif(1,0.0,1.0)
    if (test< gamma[1,1]){
      C[i] <- 0
    }
    else {
      C[i] <- 1
    }
  }
  else{
    test <- runif(1,0.0,1.0)
    if (test< gamma[2,1]){
      C[i] <- 0
    }
    else {
      C[i] <- 1
    }
  }
  if (C[i]==0) {
    X[i] <- rpois(1, lambda0[1])
  }
  else {
    X[i] <- rpois(1, lambda0[2])
  }
}
x<- X[2:T+1]
print(x)
minpars <- c(1,1,-3,-4) 
maxpars <- c(5,5,-0.5,-0.5)
# Specify how often to evaluate profile
freq <- 0.1
# Specify initial parameters for maximisation algorithm
inpars <- c(3.8,2.2,0,0)
# Give labels for x-axis of the profile plots. 
# This is normally the parameter name
label <- c("transformed(lambda1)","transformed(lambda2)","logit(gamma11)","logit(gamma12)","logit(delta1)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=pois.HMM.mllk2.m2,x,minpars,maxpars,freq,inpars,label)

# Creates likelihood profile figures on the natural scale.
xx <- seq(minpars[1],maxpars[1], by=freq)
plot(xx^2,-profileresults$lv[1,],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),main="(c)",cex.main=1.5,cex.lab=1.5,cex.axis=1.5,ylim=c(-500,-240),xlim=c(0,20))


