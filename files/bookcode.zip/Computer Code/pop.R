#============================================================
#============================================================
# Rcode for the book Parameter Redundancy and Identifiability
# By D.J. Cole
# Population growth model
#============================================================
#============================================================

#===================================================
# Data Cloning for population growth model
# Section 4.1.3.2
#===================================================

# This code needs Winbugs to be installed.

# Note if using Rsudio, you get the error 'Permission denied', you need to run Rstudio as 
# an administrator to get the code to work. (This depends on how your computer is set up
# and where winbugs is installed).

#------------------------------
# Accessing required libraries:
#-------------------------------
library(lattice)
library(coda)
library(R2WinBUGS)

#--------------------------------------------
# Code to run WinBUGS
#---------------------------------------------

#Specify the directory where WinBUGS is located
bugs.dir <- c("C:/Program Files (x86)/WinBUGS14")  

# Population growth data
# y is population size, t is the time
y <- c(111,124,133,150,165,181,201,223,250,275)
t <- c(1,2,3,4,5,6,7,8,9,10)
n <- length(y)

# Winbugs model, stored in pop.bug:
sink("pop.bug")
cat("
    model	{
    # priors 
    thetab ~ dunif(0,5)
    thetad ~ dunif(0,5)
    sigma2 ~ dunif(0,5)
    tau <- 1/sigma2
    
    for (k in 1:K){ # Additional loop for data cloning
        for(j in 1:n){ 
            meanpop[k,j] <- 100*exp((thetab-thetad)*t[j])
            y[k,j] ~ dnorm(meanpop[k,j],tau)  
        }
    }     
    }
    ",fill=TRUE)
sink()


# Parameters to be monitored
parameters <- c("thetab","thetad","sigma2")

# Assigning MCMC update values, number of iterations, burnin etc
chain <- 1 
iter <- 20000
burn	<- 10000
thin <- 1

# K is number of clones. When K = 1 this is equivalent to just using original data
K <- 1
# Data is converted to a matrix:
y2 <- matrix(rep(y,K),nrow=K,ncol=n,byrow=T)

# The data for WinBUGS
data.or <-list(n=n,y=y2,K=K,t=t)

#The initial values for WinBUGS
init.nt <- function(){list(thetab=2.2,thetad=2.1,sigma2=1)}

# Performs MCMC in WinBUGS
# This code will take a few minutes to run
pop.out <- bugs(data.or,inits=init.nt,model.file = "pop.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)

# Puts the samples into a useable format in R
# In particular results$phi1 is a vector of simulated phi1 values etc 
codapop <- read.bugs(pop.out)
results <- do.call(rbind.data.frame, codapop)

# Summarises the posterior, producing posterior means, standard deviations etc
#summary(codaintro, quantiles = c(0.025, 0.25, 0.5, 0.75, 0.975))

# svari is a vector set up to store the standardised posterior variance
# for each parameter
# The variance is found and then divided through by the variance for K = 1
# (The first value will always be 1.)
svar1<-c(var(results$thetab)/var(results$thetab))
svar2<-c(var(results$thetad)/var(results$thetad))
svar3<-c(var(results$sigma2)/var(results$sigma2))


# The code below is similar to above but repeats for different number of clones
# Here we use K = 20, 40, 60 and 100
# The standised variance is stored in svari (and then displayed on screen)
# This code will take a few minutes to run
for (kk in 1:5) {
  K<- kk*20
  y2 <- matrix(rep(y,K),nrow=K,ncol=n,byrow=T)
  data.or <-list(n=n,y=y2,K=K,t=t)
  init.nt <- function(){list(thetab=2.2,thetad=2.1,sigma2=1)}
  pop.out <- bugs(data.or,inits=init.nt,model.file = "pop.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)
  codapop <- read.bugs(pop.out)
  results2 <- do.call(rbind.data.frame, codapop)
  svar1<-c(svar1,var(results2$thetab)/var(results$thetab))
  svar2<-c(svar2,var(results2$thetad)/var(results$thetad))
  svar3<-c(svar3,var(results2$sigma2)/var(results$sigma2))
}
svar1
svar2
svar3

# Lastly the standardised variance is plotted on a graph:
KK=c(1,20,40,60,80,100)
plot(KK,1/KK,type="l",xlab="K",ylab="Standardised Variance")
points(KK,svar1,pch=0)
points(KK,svar2,pch=1)
points(KK,svar3,pch=2)
legend("right",c('1/K',expression(theta[b]),expression(theta[d]),expression(sigma^2)), lty=c(1,0,0,0),pch = c(NA,0,1,2))

#-----------------------------------------------------
# Classical data cloning
#-----------------------------------------------------

#-----------------------------------------------------------------
# Function for finding the hessian
#-----------------------------------------------------------------

hessian <- function(funfcn,x,y,delta){
  # function to calculate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}

#-----------------------------------------------------------------
# Function for finding the likelihood of population model
#-----------------------------------------------------------------
poplik <- function(pars,data){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  thetab <- pars[1]
  thetad <- pars[2]
  sigma2 <- pars[3]
  loglik <-0
  for (i in 1:length(data$y)) {
    likcont <- dnorm( data$y[i], mean = 100*exp((thetab-thetad)*data$t[i]), sd = sqrt(sigma2))
    if (likcont==0){
      loglik <- loglik-100000
    }
    else {
      loglik<-loglik+log(likcont)
    }
  }
  return(-loglik)
}
data <- list(y=y,t=t)
inpars <- c(2.2,2.1,1)
maxlik <- optim(inpars,poplik,data=data,method="L-BFGS-B",hessian=FALSE)
maxlik$par
h=hessian(poplik,maxlik$par,data,0.00001)
# Not possible to find standard errors, as cannot find inverse:
solve(h)
