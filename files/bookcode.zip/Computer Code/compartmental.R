#==========================================================
#==========================================================
# R code for Book Parameter Redundancy and Identifiability
# by Diana J. Cole
# R code is for Three Compartment Model
# Section 2.2.2
#==========================================================
#==========================================================


# --------------------------------------------------------------
# R-sq function for Three Compartment Model
# --------------------------------------------------------------
godchaplsq <- function(pars,yy){
  theta01 <- pars[1]
  theta21 <- pars[2]
  theta32 <- pars[3]
  n <- length(yy)/2
  y <- yy[1:n]
  t <- yy[(n+1):(2*n)]
  R<-0
  for (i in 1:n) {
    Ey <- -((theta01+theta21)*exp(-theta32*t[i])-theta32*exp(-(theta01+theta21)*t[i])-theta01-theta21+theta32)*theta21/((theta01+theta21)*(theta01+theta21-theta32))
    R <-R+(Ey-y[i])^2
  }
  return(R)
}

# -----------------------------------------------------------------
# R-sq function for Three Compartment Model - fixing 1st parameter
# -----------------------------------------------------------------
godchaplsqfix1 <- function(pars,yy,fixpar){
  theta01 <- fixpar
  theta21 <- pars[1]
  theta32 <- pars[2]
  n <- length(yy)/2
  y <- yy[1:n]
  t <- yy[(n+1):(2*n)]
  R<-0
  for (i in 1:n) {
    Ey <- -((theta01+theta21)*exp(-theta32*t[i])-theta32*exp(-(theta01+theta21)*t[i])-theta01-theta21+theta32)*theta21/((theta01+theta21)*(theta01+theta21-theta32))
    R <-R+(Ey-y[i])^2
  }
  return(R)
}

# -----------------------------------------------------------------
# R-sq function for Three Compartment Model - fixing 2nd parameter
# -----------------------------------------------------------------
godchaplsqfix2 <- function(pars,yy,fixpar){
  theta01 <- pars[1]
  theta21 <- fixpar
  theta32 <- pars[2]
  n <- length(yy)/2
  y <- yy[1:n]
  t <- yy[(n+1):(2*n)]
  R<-0
  for (i in 1:n) {
    Ey <- -((theta01+theta21)*exp(-theta32*t[i])-theta32*exp(-(theta01+theta21)*t[i])-theta01-theta21+theta32)*theta21/((theta01+theta21)*(theta01+theta21-theta32))
    R <-R+(Ey-y[i])^2
  }
  return(R)
}

# -----------------------------------------------------------------
# R-sq function for Three Compartment Model - fixing 3rd parameter
# -----------------------------------------------------------------
godchaplsqfix3 <- function(pars,yy,fixpar){
  theta01 <- pars[1]
  theta21 <- pars[2]
  theta32 <- fixpar
  n <- length(yy)/2
  y <- yy[1:n]
  t <- yy[(n+1):(2*n)]
  R<-0
  for (i in 1:n) {
    Ey <- -((theta01+theta21)*exp(-theta32*t[i])-theta32*exp(-(theta01+theta21)*t[i])-theta01-theta21+theta32)*theta21/((theta01+theta21)*(theta01+theta21-theta32))
    R <-R+(Ey-y[i])^2
  }
  return(R)
}

# Data
y <- c(0.07,0.21,0.33,0.43,0.51,0.58,0.63,0.66,0.69)
t <- c(0.5, 1, 1.5, 2, 2.5,3,3.5,4,4.5)
yy<-c(y,t)

# Finding parameter values that minimise the 
inpars<-c(0.5,2,0.5)
godchaplsq(inpars,yy)
lsq <- optim(inpars,godchaplsq,y=yy,method="L-BFGS-B",hessian=TRUE)
lsq

inpars<-c(0.12,0.42,2.15)
godchaplsq(inpars,yy)
lsq <- optim(inpars,godchaplsq,y=yy,method="L-BFGS-B",hessian=TRUE)
lsq


# Plotting the R-sq profile plots:
par(mfrow=c(2,2))

Rv <- c( )
av1 <- seq(0.05,0.37, by=0.01)
inpars<-c(0.4,2.5)
for (i in 1:length(av1)) {
   lsq <- optim(inpars,godchaplsqfix1,y=yy,fixpar=av1[i],method="L-BFGS-B",hessian=TRUE)
   Rv <- c(Rv,lsq$value)
}
av2 <- seq(0.38,0.6, by=0.01)
inpars<-c(2,0.5)
for (i in 1:length(av2)) {
  lsq <- optim(inpars,godchaplsqfix1,y=yy,fixpar=av2[i],method="L-BFGS-B",hessian=TRUE)
  Rv <- c(Rv,lsq$value)
}
Rv
plot(c(av1,av2),Rv,type = "l",ylab=expression(R^2),xlab=expression(theta[0][1]))

Rv <- c( )
av1 <- seq(0.35,0.5, by=0.01)
inpars<-c(0.1,2.5)
for (i in 1:length(av1)) {
  lsq <- optim(inpars,godchaplsqfix2,y=yy,fixpar=av1[i],method="L-BFGS-B",hessian=TRUE)
  Rv <- c(Rv,lsq$value)
}
av2 <- seq(0.5,2.5, by=0.01)
inpars<-c(0.5,0.5)
for (i in 1:length(av2)) {
  lsq <- optim(inpars,godchaplsqfix2,y=yy,fixpar=av2[i],method="L-BFGS-B",hessian=TRUE)
  Rv <- c(Rv,lsq$value)
}
plot(c(av1,av2),Rv,type = "l",ylab=expression(R^2),xlab=expression(theta[21]))

Rv <- c( )
av1 <- seq(0.4,0.6, by=0.01)
inpars<-c(0.5,2)
for (i in 1:length(av1)) {
  lsq <- optim(inpars,godchaplsqfix3,y=yy,fixpar=av1[i],method="L-BFGS-B",hessian=TRUE)
  Rv <- c(Rv,lsq$value)
}
av2 <- seq(0.7,3, by=0.01)
inpars<-c(0.1,0.4)
for (i in 1:length(av2)) {
  lsq <- optim(inpars,godchaplsqfix3,y=yy,fixpar=av2[i],method="L-BFGS-B",hessian=TRUE)
  Rv <- c(Rv,lsq$value)
}
plot(c(av1,av2),Rv,type = "l",ylab=expression(R^2),xlab=expression(theta[32]))

