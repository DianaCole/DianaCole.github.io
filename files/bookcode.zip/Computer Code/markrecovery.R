#==========================================================
#==========================================================
# R code for Book Parameter Redundancy and Identifiability
# by Diana J. Cole
# R code is for Mark-Recovery Model
# Sections 2.1.2, 4.1.1.2, 4.1.4.1, 4.4.1.1
#==========================================================
#==========================================================




#=================================================================
# Log-Likelihood Profile for mark-recovery model - Section 2.1.2
#=================================================================

#-----------------------------------------------------
# Log-Likelihood Profile Method Functions
#-----------------------------------------------------

profileplot <- function(funfcn,y,minpars,maxpars,freq,inpars,label) {
  # profileplot plots the log-likelihood profile for all parameters
  # funfcn needs to be a function that returns the negative log-likelihood
  # minpars and maxpars specify the minimum and maximum values for plots
  # freq specifies how often the log-likelihood profile is evaluated
  # inpars is a vector of inital values
  # label is a vector that specifies labels for the x-axis of the profile
  # plots, typically this would be the names of the parameters
  
  lv <- matrix(0,nrow=length(inpars),ncol=max((maxpars-minpars)/freq+1))
  parvs <- matrix(0,nrow=((length(inpars)-1)*length(inpars)),ncol=max((maxpars-minpars)/freq+1))
  for (j in 1:length(inpars) ) {
    fixparpos <- j
    av <- seq(minpars[fixparpos],maxpars[fixparpos], by=freq)
    
    for (i in 1:length(av)){
      fixpar <- c(av[i])
      if (fixparpos==1){
        inpars2 <- inpars[2:length(inpars)]
      }
      else if (fixparpos==length(inpars)) {
        inpars2 <- inpars[1:length(inpars)-1]
      }
      else {
        inpars2 <- c(inpars[1:(fixparpos-1)],inpars[(fixparpos+1):length(inpars)])
      }
      maxlik <- optim(par=inpars2,fn=profilelik,y=y,funfcn=funfcn,fixpar=fixpar,fixparpos=fixparpos,method="L-BFGS-B",hessian=TRUE)
      parvs[((j-1)*(length(inpars)-1)+1):((j-1)*(length(inpars)-1)+length(inpars)-1),i] <- maxlik$par
      lv[j,i] <- round(maxlik$value, digits = 2)
      
    }
    plot(av,-lv[j,1:length(av)],type = "l",ylab="log-lik",xlab=label[j])
  }
  return(list(lv=lv,parv=parvs))
}

profilelik <- function(par,y,funfcn,fixpar,fixparpos) {
  # profilelik returns the log-likelihood needed for a profile log-likelihood
  # Has the ability to fix more than one parameter (needed for subset profiling)
  # funfcn is the name of the function
  # pars are the parameters to be maximised
  # fixpar is the values of the fixed parameter
  # fixparpos is the position of the fixed parameter
  np <- length(par)
  nf <- length(fixpar)
  parsprev <- 0
  parscurr <- 0
  if (fixparpos[1]>1){
    parsprev <- 1
    parscurr <- fixparpos[1]-1
    z <- c(par[1:fixparpos[1]-1],fixpar[1])
  }
  else{
    z=c(fixpar[1])
  }
  if (nf>2) {
    for (i in 2:nf) {
      if (fixparpos[i]-fixparpos[i-1]>1) {
        parsprev <- parscurr;
        parscurr <- parscurr+fixparpos[i]-fixparpos[i-1]-1
        z <- c(z,par[parsprev+1:parscurr],fixpar[i])
      }
      else {
        z <-c(z,fixpar[i])
      }
    }
  }
  if (parscurr<np) {
    z <- c(z,par[parscurr+1:np])
  }
  
  y <- do.call("funfcn",list(z,y)) 
  return(y)
}


#--------------------
# Mark-Recovery Data
#--------------------


N<-matrix(c(800	,	315	,	205	,	133	,	87	,	5000	,
            0	,	800	,	315	,	205	,	133	,	5000	,
            0	,	0	,	800	,	315	,	205	,	5000	,
            0	,	0	,	0	,	800	,	315	,	5000	,
            0	,	0	,	0	,	0	,	800	,	5000	
),nrow=5,ncol=6,byrow=TRUE)

# --------------------------------------------------------------
# Log-Likelihood function for reparmeterised mark-recovery model
# --------------------------------------------------------------
ringlik2 <- function(pars,y){
  # This function returns the negative log-likelihood mark-recovery model
  phia <- expit(pars[1])
  beta1 <- expit(pars[2])
  beta2 <- expit(pars[3])
  
  N <-y
  n1 <- dim(N)[1]
  n2 <- dim(N)[2]-1
  
  l <-0
  for (i in 1:n1) {
    probnot <- 1
    for (j in i:n2) {
      if (i==j) {
        prob <- beta1
      }
      else {
        prob <- phia^(j-i-1)*(1-phia)*beta2
      }
      probnot <- probnot-prob
      l <- l + N[i,j]*log(prob)
    }
    
    l <- l + (N[i,n2+1]-sum(N[i,1:n2]))*log(probnot)
  }
  return(-l)
}

#------------------------------------------------------------------
# Finding maximum liklihood estimates using reparameterised model
#------------------------------------------------------------------

inpars <- c(logit(0.6),logit(0.65),logit(0.4),logit(0.3))
maxlik <- optim(inpars,ringlik,y=N,hessian=TRUE)
#print(maxlik)
maxlik$par
pars <- c(expit(maxlik$par))
pars



phias <- 0.65
beta1s <- 0.16
beta2s <- 0.18
inpars <- c(logit(phias),logit(beta1s),logit(beta2s))
maxlik <- optim(inpars,ringlik2,y=N,method="L-BFGS-B",hessian=TRUE)
pars <- c(expit(maxlik$par))
pars

#-----------------------------------------------------------------------------
# Producing log-lik profile for parameterisation phi1, phia, lambda1, lambdaa
#-----------------------------------------------------------------------------

# Specify minimum and maximum values for profile plots for all 4 parameters
minpars <- c(0.3,0.3,-1,-1) 
maxpars <- c(0.9,0.9,1,1)
# Specify how often to evaluate profile
freq <- 0.01
# Specify initial parameters for maximisation algorithm
inpars <- c(0.4,0.6,-0.4,-0.8)
# Give labels for x-axis of the 3 profile plots. 
# This is normally the parameter name
label <- c("logit(phi1)","logit(phia)","log(lambda1)","log(lambdaa)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=ringlik,N,minpars,maxpars,freq,inpars,label)

# Producing log-likelihood plots on the origional scale
lv=profileresults$lv
par(mfrow=c(3,2))
x<-1/(1+exp(-seq(minpars[1],maxpars[1], by=freq)))
nn<-length(x)
plot(x,-lv[1,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[1]),main="(a)")
x<-1/(1+exp(-seq(minpars[2],maxpars[2], by=freq)))
nn<-length(x)
plot(x,-lv[2,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[a]),main="(b)")
x<-1/(1+exp(-seq(minpars[3],maxpars[3], by=freq)))
nn<-length(x)
plot(x,-lv[3,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),main="(c)")
x<-1/(1+exp(-seq(minpars[4],maxpars[4], by=freq)))
nn<-length(x)
plot(x,-lv[4,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[a]),main="(d)")
# Producing plots of fixed phi1 against other maximised parameters
x<-1/(1+exp(-seq(minpars[1],maxpars[1], by=freq)))
nn<-length(x)
plot(x,1/(1+exp(-profileresults$parv[2,1:nn])),type = "l",ylab=expression(lambda[1]),xlab=expression(phi[1]),main="(e)")
plot(x,1/(1+exp(-profileresults$parv[3,1:nn])),type = "l",ylab=expression(lambda[a]),xlab=expression(phi[1]),main="(f)")

#-----------------------------------------------------------------------------
# Producing log-lik profile for parameterisationphi1, phia, beta1, beta
#-----------------------------------------------------------------------------


# Specify minimum and maximum values for profile plots for all 3 parameters
minpars <- c(0.3,-2,-2) 
maxpars <- c(0.9,-1.3,-0.5)
# Specify how often to evaluate profile
freq <- 0.01
# Specify initial parameters for maximisation algorithm
inpars <- c(0.6,0.1,0.1)
# Give labels for x-axis of the 3 profile plots. 
# This is normally the parameter name
label <- c("logit(phia)","logit(beta1)","log(betaa)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=ringlik2,N,minpars,maxpars,freq,inpars,label)

# Producing log-likelihood plots on the origional scale
lv=profileresults$lv
par(mfrow=c(2,2))
x<-1/(1+exp(-seq(minpars[1],maxpars[1], by=freq)))
nn<-length(x)
plot(x,-lv[1,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[a]),main="(a)")
x<-1/(1+exp(-seq(minpars[2],maxpars[2], by=freq)))
nn<-length(x)
plot(x,-lv[2,1:nn],type = "l",ylab="log-likelihood",xlab=expression(beta[1]),main="(b)")
x<-1/(1+exp(-seq(minpars[3],maxpars[3], by=freq)))
nn<-length(x)
plot(x,-lv[3,1:nn],type = "l",ylab="log-likelihood",xlab=expression(beta[2]),main="(c)")


#============================================================
# Hessian Method for mark-recovery model - Section 4.1.1.2
#=============================================================


# --------------------------------------------
# Logit and Inverse Logit (expit) functions
# --------------------------------------------
expit <- function(xval) { 
  1/(1+exp(-xval))
}
logit <- function(xval) {
  log(xval/(1-xval))
}


# -----------------------------------------------
# Log-Likelihood function for mark-recovery model
# -----------------------------------------------
ringlik <- function(pars,y){
  # This function returns the negative log-likelihood mark-recovery model
  phi1 <- expit(pars[1])
  phia <- expit(pars[2])
  lambda1 <- expit(pars[3])
  lambdaa <- expit(pars[4])
  
  N<-y
  
  n1 <- dim(N)[1]
  n2 <- dim(N)[2]-1
  
  l <-0
  for (i in 1:n1) {
    probnot <- 1
    for (j in i:n2) {
      if (i==j) {
        prob <- (1-phi1)*lambda1
      }
      else {
        prob <- phi1*phia^(j-i-1)*(1-phia)*lambdaa
      }
      probnot <- probnot-prob
      l <- l + N[i,j]*log(prob)
      
    }
    l <- l + (N[i,n2+1]-sum(N[i,1:n2]))*log(probnot)
  }
  return(-l)
}


# --------------------------------------------------------
# Hessian Method Functions
# --------------------------------------------------------
hessianmethod <- function(funfcn,pars,y,delta,epsilon,print=TRUE){
  # Applies the hessian method
  # funfcn - function which return negative loglikelihood
  # pars - parameter values at which hessian is evaluated
  # y - data to be passed into likelihood
  # delta - error used in calculating Hessian and cut-off
  # epsilon - cut-off for identifiable parameters
  # suggested values: delta = 0.00001, epsilon = 0.01
  
  # cut-off used delta*p, where p is no. pars
  cutoff <- delta*length(pars) 
  # Finds the hessian matrix:
  h <- do.call("hessian",list(funfcn,pars,y,delta)) 
  # Calculates eigenvalue:
  E <- eigen(h) 
  # Find standardised eigenvalues:
  standeigenvalues <- abs(E$values)/max(abs(E$values)) 
  # Find number of estimable parameters number of parameters:
  noestpars <- 0
  smalleig <- c( )
  for (i in 1:length(pars)) {
    if (standeigenvalues[i] >= cutoff) {
      noestpars <- noestpars + 1
    } 
    else {
      smalleig <- c(smalleig,i)
    }
  }
  
  # Find identifiable parameters if parameter redundant:
  identpars <- c( )
  if (min(standeigenvalues) < cutoff) {
    
    for (i in 1:length(pars)) {
      indent <- 1
      for (j in 1:length(smalleig)) {
        if (abs(E$vectors[i,smalleig[j]]) > epsilon) {
          indent <- 0
        }
      }
      if (indent==1) {
        identpars <- c(identpars,i)
      }
    }
  } 
  
  if (print) {
    # Prints whether model is parameter redundant or not
    if (min(standeigenvalues) < cutoff) {
      cat("model is non-identifiable or parameter redundant")
      cat("\n")
      if (is.null(identpars)) {
        cat('none of the original parameters are estimable')
      }
      else {
        cat('estimable parameters',identpars) 
      }
    } 
    else {
      cat("model is identifiable or not parameter redundant")
    }
    cat("\n")  
    cat('smallest standardised eigenvalue',min(standeigenvalues)) 
    cat("\n")  
    cat('number of estimable parameters',noestpars) 
  }
  result <- list(standeigenvalues=standeigenvalues,noestpars=noestpars,identpars=identpars,E=E)
  return(result)
}

hessian <- function(funfcn,x,y,delta){
  # function to calculate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}

#-------------------------
# Mark-Recovery Data Set 1
#-------------------------
N<-matrix(c(58  ,  29  ,  12  ,   5  ,   3  ,   3  ,   0   ,  0    , 2  ,   0 , 888,
            0    ,  66  ,  22  ,  15  ,  15  ,   3  ,   3   ,  1    , 0  ,   0 , 875,
            0   ,   0   ,  58  ,  29  ,  13  ,   7  ,   7   ,  2    , 0  ,   1 , 883,
            0    ,  0    ,  0    ,  68  ,  25  ,  18  ,   9   ,  7    , 0  ,   2 , 871,
            0    ,  0    ,   0   ,  0    ,  66  ,  33  ,  10   ,  3    , 1  ,   1 , 886,
            0    ,  0    ,   0   ,   0   , 0    ,  61  ,  24   , 16    , 7  ,   5 , 887,
            0    ,   0   ,   0   ,   0   , 0    , 0    ,  66   , 28    , 7  ,  11 , 888,
            0    ,   0   ,   0   ,   0   , 0    , 0    ,  0    , 59    ,26  ,   8 , 907,
            0    ,   0   ,   0   ,   0   , 0    , 0    ,  0    ,  0    ,53  ,  27 , 920,
            0   ,    0  ,    0  , 0    , 0    , 0    ,  0    ,  0    ,   0 ,  63, 937	
),nrow=10,ncol=11,byrow=TRUE)

#--------------------
# Hessian method
#--------------------

# Finding MLEs
inpars <- c(logit(0.2),logit(0.5),logit(0.1),logit(0.3))
maxlik <- optim(inpars,ringlik,y=N,hessian=TRUE)
maxlikpar<-maxlik$par
pars <- c(expit(maxlik$par))
pars

# Hessian method:
results <- hessianmethod(ringlik,maxlikpar,N,0.00001,0.01,print=TRUE)
results

#-------------------------
# Mark-Recovery Data Set 2
#-------------------------
N<-matrix(c( 56  , 37  ,   9  ,   5  ,   3  ,   0  ,   0  ,   0  ,   0  ,   1 , 889 ,
             0   , 67  ,  31  ,  28  ,   4  ,   5  ,   3  ,   3  ,   1  ,   0 , 858 ,
             0   , 0    ,  60  ,  27  ,  14  ,   9  ,   2  ,   0  ,   2  ,   1 , 885 ,
             0   , 0   , 0    ,  57  ,  27  ,  16  ,   8  ,   0  ,   1  ,   1  , 890 ,
             0   , 0   , 0    , 0    ,  64  ,  24  ,  10  ,   8  ,   4  ,   0 , 890 ,
             0   , 0   , 0    , 0    , 0    ,  66  ,  35  ,  17  ,   8  ,   3 , 871 ,
             0   , 0   , 0    , 0    , 0    , 0    ,  57  ,  32  ,  15  ,   8 , 888 ,
             0   , 0   , 0    , 0    , 0    , 0    , 0    ,  71  ,  34  ,  23 , 872 ,
             0   , 0   , 0    , 0    , 0    , 0    , 0    , 0    ,  64  ,  36 , 900 ,
             0   , 0   , 0    , 0    , 0    , 0    , 0    , 0    , 0    ,  65 , 935
),nrow=10,ncol=11,byrow=TRUE)

#--------------------
# Hessian method
#--------------------

# Finding MLEs
inpars <- c(logit(0.55),logit(0.49),logit(0.14),logit(0.1))
maxlik <- optim(inpars,ringlik,y=N,hessian=TRUE)
maxlikpar<-maxlik$par
pars <- c(expit(maxlik$par))
pars

# Hessian method:
results <- hessianmethod(ringlik,maxlikpar,N,0.00001,0.01,print=TRUE)
results




#=========================================================
# Near-Redundancy using Hessian method - Section 4.4.1.1
#=========================================================

# ----------------------------------------------------------------
# Log-Likelihood function for near-redundant mark-recovery model
# -----------------------------------------------------------------
ringlik3 <- function(pars,y){
  # This function returns the negative log-likelihood mark-recovery model
  phi1 <- pars[1:3]
  phia <- pars[4]
  lambda1 <- pars[5]
  lambdaa <- pars[6]
  
  N<-y
  
  n1 <- dim(N)[1]
  n2 <- dim(N)[2]-1
  
  l <-0
  for (i in 1:n1) {
    probnot <- 1
    for (j in i:n2) {
      if (i==j) {
        prob <- (1-phi1[i])*lambda1
      }
      else {
        prob <- phi1[i]*phia^(j-i-1)*(1-phia)*lambdaa
      }
      probnot <- probnot-prob
      l <- l + N[i,j]*log(prob)
      
    }
    l <- l + (N[i,n2+1]-sum(N[i,1:n2]))*log(probnot)
    
  }
  return(-l)
}

#-------------------------
# Mark-Recovery Data Set
#-------------------------
N<-matrix(c(60, 40, 20, 1000, 
            0 , 59, 41, 1000,
            0 ,  0, 58, 1000
),nrow=3,ncol=4,byrow=TRUE)



# Finding MLEs
inpars <- c(0.40,0.41,0.42,0.5,0.1,0.2)
maxlik <- optim(inpars,ringlik3,y=N,hessian=TRUE)
maxlikpar<-maxlik$par
pars <- maxlik$par
pars

# Step 1 (Note default program does not output Hessian)
hessian(ringlik3,maxlikpar,N,0.00001)
round(hessian(ringlik3,maxlikpar,N,0.00001),digits=2)
# Hessian method:
results <- hessianmethod(ringlik3,maxlikpar,N,0.00001,0.01,print=TRUE)
# Step 2 eigenvalues
results$E$values
# Step 3 standardised eigenvalues
results$standeigenvalues




#===================================================================
# Practical Identifiability for mark-recovery model - Section 4.4.2.1
#===================================================================

# --------------------------------------------------------------------------------------------
# Log-Likelihood function for near-redundant mark-recovery model with logist link functions
# -----------------------------------------------------------------------------------------
ringlik4 <- function(pars,y){
  # This function returns the negative log-likelihood mark-recovery model
  phi1 <- expit(pars[1:3])
  phia <- expit(pars[4])
  lambda1 <- expit(pars[5])
  lambdaa <- expit(pars[6])
  
  N<-y
  
  n1 <- dim(N)[1]
  n2 <- dim(N)[2]-1
  
  l <-0
  for (i in 1:n1) {
    probnot <- 1
    for (j in i:n2) {
      if (i==j) {
        prob <- (1-phi1[i])*lambda1
      }
      else {
        prob <- phi1[i]*phia^(j-i-1)*(1-phia)*lambdaa
      }
      probnot <- probnot-prob
      l <- l + N[i,j]*log(prob)
      
    }
    l <- l + (N[i,n2+1]-sum(N[i,1:n2]))*log(probnot)
    
  }
  return(-l)
}

#-------------------------
# Mark-Recovery Data Set 1
#-------------------------
N<-matrix(c(60, 40, 20, 1000, 
            0 , 59, 41, 1000,
            0 ,  0, 58, 1000
),nrow=3,ncol=4,byrow=TRUE)

#------------------------------------------------
# Finding maximum likelihood estimates
#------------------------------------------------
inpars <- logit(c(0.40,0.41,0.42,0.5,0.1,0.2))
maxlik <- optim(inpars,ringlik4,y=N,hessian=TRUE)
maxlikpar<-maxlik$par
pars <- expit(maxlik$par)
pars

#---------------------------
# Producing log-lik profile 
#----------------------------

# Specify minimum and maximum values for profile plots for all 4 parameters
minpars <- c(-3,-3,-3,-3,-3,-3) 
maxpars <- c(3,3,3,3,3,3)
# Specify how often to evaluate profile
freq <- 0.1
# Specify initial parameters for maximisation algorithm
inpars <- logit(c(0.40,0.41,0.42,0.5,0.1,0.2))
# Give labels for x-axis of the 3 profile plots. 
# This is normally the parameter name
label <- c("logit(phi11)","logit(phi12)","logit(phi13)","logit(phia)","logit(lambda1)","logit(lambda2)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=ringlik4,N,minpars,maxpars,freq,inpars,label)

# Producing log-likelihood plots on the origional scale
# Dotted line chisq_12 below maximum
lv=profileresults$lv
par(mfrow=c(3,2))
x<-1/(1+exp(-seq(minpars[1],maxpars[1], by=freq)))
nn<-length(x)
plot(x,-lv[1,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[11]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[2],maxpars[2], by=freq)))
nn<-length(x)
plot(x,-lv[2,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[12]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[3],maxpars[3], by=freq)))
nn<-length(x)
plot(x,-lv[3,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[13]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[4],maxpars[4], by=freq)))
nn<-length(x)
plot(x,-lv[4,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[a]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[5],maxpars[5], by=freq)))
nn<-length(x)
plot(x,-lv[5,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[6],maxpars[6], by=freq)))
nn<-length(x)
plot(x,-lv[6,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[a]),ylim=c(-1120,-1100) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)


#-------------------------
# Mark-Recovery Data Set 2
#-------------------------
N<-matrix(c(9000, 1000, 500, 100000, 
            0 , 6000, 4000, 100000,
            0 ,  0, 7000, 100000
),nrow=3,ncol=4,byrow=TRUE)



#------------------------------------------------
# Finding maximum likelihood estimates
#------------------------------------------------
inpars <- logit(c(0.1,0.4,0.3,0.5,0.1,0.2))
maxlik <- optim(inpars,ringlik4,y=N,hessian=TRUE)
maxlikpar<-maxlik$par
pars <- expit(maxlik$par)
pars

#---------------------------
# Producing log-lik profile 
#----------------------------

# Specify minimum and maximum values for profile plots for all 3 parameters
minpars <- c(-3,-3,-3,-3,-3,-3) 
maxpars <- c(3,3,3,3,3,3)
# Specify how often to evaluate profile
freq <- 0.05
# Specify initial parameters for maximisation algorithm
inpars <- logit(c(0.40,0.41,0.42,0.5,0.1,0.2))
# Give labels for x-axis of the 3 profile plots. 
# This is normally the parameter name
label <- c("logit(phi11)","logit(phi12)","logit(phi13)","logit(phia)","logit(lambda1)","logit(lambda2)")
# Produce the profile plots on the logit scale. 
# The log-likelihood values are stored in lv.
profileresults <-profileplot(funfcn=ringlik4,N,minpars,maxpars,freq,inpars,label)

# Producing log-likelihood plots on the origional scale
# Dotted line chisq_12 below maximum
lv=profileresults$lv
par(mfrow=c(3,2))
x<-1/(1+exp(-seq(minpars[1],maxpars[1], by=freq)))
nn<-length(x)
plot(x,-lv[1,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[11]),ylim=c(-103510,-103450),xlim=c(0,0.3))
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[2],maxpars[2], by=freq)))
nn<-length(x)
plot(x,-lv[2,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[12]),ylim=c(-103510,-103450),xlim=c(0.2,0.6) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[3],maxpars[3], by=freq)))
nn<-length(x)
plot(x,-lv[3,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[13]),ylim=c(-103510,-103450),xlim=c(0.1,0.5))
lines(c(0,1),c(1,1)*(-maxlik$value-qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[4],maxpars[4], by=freq)))
nn<-length(x)
plot(x,-lv[4,1:nn],type = "l",ylab="log-likelihood",xlab=expression(phi[a]),ylim=c(-103510,-103450),xlim=c(0.3,0.7) )
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[5],maxpars[5], by=freq)))
nn<-length(x)
plot(x,-lv[5,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[1]),ylim=c(-103510,-103450),xlim=c(0,0.4))
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)
x<-1/(1+exp(-seq(minpars[6],maxpars[6], by=freq)))
nn<-length(x)
plot(x,-lv[6,1:nn],type = "l",ylab="log-likelihood",xlab=expression(lambda[a]),ylim=c(-103510,-103450),xlim=c(0.1,0.4))
lines(c(0,1),c(1,1)*(-maxlik$value-0.5*qchisq(0.95,6)),lty=2)





