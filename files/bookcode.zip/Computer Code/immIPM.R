#==========================================================
#==========================================================
# R code for Book Parameter Redundancy and Identifiability
# by Diana J. Cole
# R code is for Immigration Integrated Model
# Section 9.2.2
#==========================================================
#==========================================================


library(lattice)
library(coda)
library(R2WinBUGS)

#------------------------------
# Function for Prior Overlap
#-------------------------------

overlap <- function(data,prior,minv,maxv,freqv,xlabel) {
  # OVERLAP calculates the proportion overlap between the
  # prior and posterior using a kernel density to approximate
  # posterior
  # Also plots a graph of prior and posterior
  # 'data' contains the posterior chain
  # 'prior' contains a vector of prior values evaluated at same interval
  # as 'minv', 'maxv' and 'freqv' values given
  
  k1 <- 0.9 # Controls the smoothness of the kernel
  
  x <- seq(minv,maxv,freqv)
  nn <- length(x)
  fK <- c(rep(0,nn))
  
  overlap<-0
  for (i in 1:nn) {
    fK[i]<-kernel(x[i],data,k1)
    if (fK[i]<prior[i]){
      overlap<-overlap+fK[i]*freqv
    }
    else {
      overlap=overlap+prior[i]*freqv
    }
  }
  
  plot(x,fK,type = "l",ylab="f",xlab=xlabel)
  lines(x,prior,lty=2)  
  return(overlap)
}


kernel <- function(y,data,k1) {
  # KERNEL Calculates a kernel density estimate for a sample in 'data'.
  #   'y' is the value at which we want the kernel estimate.
  #   'k1' can be chosen to vary the amount of smoothing;
  #   Calls the function DELTA.
  
  n <- length(data)
  h <- k1*min(sd(data),IQR(data)/1.34)/n^0.2	
  
  z <- 0
  for (i in 1:n ) {
    z<-z+delta((y-data[i])/h)
  }				            
  z<-z/(n*h);
}

delta <- function(u) {
  # DELTA calculates a normal kernel
  
  y <-(exp(-u*u/2))/sqrt(2*pi);
}

#--------------------------------------------
# Winbugs Code
#---------------------------------------------

#SPECIFY THE DIRECTORY WHERE WinBUGS IS LOCATED
bugs.dir <- c("C:/Program Files (x86)/WinBUGS14")  


# Population count data
y <- c(14,9,8,15,17,15,13,9,8,9,9,10,12,11,10,11,10,7,5,5,8,12,14,15,18,21)
T <- length(y)
# Capture recapture data for females
mfem <- matrix(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,
                 0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,
                 0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,
                 0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,
                 0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,9,
                 0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,15,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,14,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,17,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,17,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,3,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,4,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,11,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,13,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,15,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,15,
                 1,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,
                 0,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,
                 0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,
                 0,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,
                 0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,
                 0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                 0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                 0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,
                 0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                 0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                 0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,2,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,3,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,2,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,2,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,1,0,0,1,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,4,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,3,
                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3),nrow=50,ncol=26,byrow=T)


# Winbugs model:
sink("IPM_IMM.bug")
cat("
    model	{
    # priors 
    phij ~ dunif(0,1)
    phia ~ dunif(0,1)
    im~dunif(0,5)
    rho ~ dunif(0,30)
    p ~ dunif(0,1)
    
    # Census
    for (k in 1:K){
    N1[k,1] ~ dnorm(100,0.0001)I(0,)     		
    NadSurv[k,1] ~ dnorm(100,0.0001)I(0,)  	 
    Nadimm[k,1] ~ dnorm(100,0.0001)I(0,) 	
    Ntot[k,1] <- NadSurv[k,1] + Nadimm[k,1] + N1[k,1]  
    }
    
    for (k in 1:K){
    for(t in 2:T){ 
    mean1[k,t] <- 0.5*rho*phij*Ntot[k,t-1]
    N1[k,t] ~ dpois(mean1[k,t])
    mpo[k,t] <- Ntot[k,t-1]*im
    NadSurv[k,t] ~ dbin(phia,Ntot[k,t-1])
    Nadimm[k,t] ~ dpois(mpo[k,t])
    Ntot[k,t] <- NadSurv[k,t] + Nadimm[k,t] + N1[k,t]
    y[k,t] ~ dpois(Ntot[k,t])
    }
    }     
    
    # CJS 
    q <- 1-p
    for( i in 1:2*(T-1)) {
       m[i,1:T] ~ dmulti(pr[i,],r[i])
    } 	
    for(i in 1:2*(T-1)) {
       r[i] <- sum(m[i,])
    } 
    
    # m-array cell probabilities for juveniles
    for(i in 1:(T-1)) {
       pr[i,i]<-phij*p
       for(j in (i+1):(T-1)) {
          pr[i,j] <- phij*pow(phia,j-i)*pow(q,j-i)*p
       } 
       for( j in 1:(i-1)) {
           pr[i,j] <- 0
       }
       pr[i,T] <- 1-sum(pr[i,1:(T-1)])
    } 
    # m-array cell probabilities for adults
    for(i in 1:(T-1))            {
       pr[i+T-1,i] <- phia*p
       for(j in (i+1):(T-1))            {
         pr[i+T-1,j] <-pow(phia,j-i+1)*pow(q,j-i)*p 
       } 
       for( j in 1:(i-1))                {
          pr[i+T-1,j] <- 0
       } 
       pr[i+T-1,T] <- 1-sum(pr[i+T-1,1:(T-1)])
    } 
    
    }  
    ",fill=TRUE)
sink()

K <- 1
y2 <- matrix(rep(y,K),nrow=K,ncol=T,byrow=T)
mK <- mfem*K
data.or <-list(T=T,y=y2,K=K,m=mK)
N1 <- c(rep(50,T))
N12 <- matrix(rep(N1,K),nrow=K,ncol=T,byrow=T)
NadSurv <- y2/2
Nadimm <- y2/2
inits <- function(){list(phij=0.4,phia=0.6,rho=2.5,im=0.1,p=0.4,
                         N1=N12,NadSurv=NadSurv,Nadimm=Nadimm)}
parameters <- c("phij","phia","rho","im","p")
chain <- 1 
iter <- 20000 
burn	<- 10000
thin <- 1

imm.out <- bugs(data=data.or,inits=inits,model.file = "IPM_IMM.bug",
                parameters=parameters, n.chains =chain, n.iter =iter,
                n.burnin=burn,n.thin=thin,debug=F, 
                bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)

codaimm <- read.bugs(imm.out)
summary(codaimm, quantiles = c(0.025, 0.25, 0.5, 0.75, 0.975))
results <- do.call(rbind.data.frame, codaimm)

post<-results$rho
minv<-0
maxv<-30
freqv<-0.1
xx <- seq(minv,maxv,freqv)
xlabel<-expression(rho)
prior <-  dunif(xx,0,30)
rhooverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
rhooverlap

post<-results$im
minv<-0
maxv<-5
freqv<-0.1
xx <- seq(minv,maxv,freqv)
xlabel<-expression(im)
prior <-  dunif(xx,0,5)
imoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
imoverlap

post<-results$phia
minv<-0
maxv<-1
freqv<-0.01
xx <- seq(minv,maxv,freqv)
xlabel<-expression(phi[a])
prior <-  dunif(xx,0,1)
phiaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phiaoverlap

post<-results$phij
minv<-0
maxv<-1
freqv<-0.01
xx <- seq(minv,maxv,freqv)
xlabel<-expression(phi[j])
prior <-  dunif(xx,0,1)
phijoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phijoverlap

post<-results$p
minv<-0
maxv<-1
freqv<-0.01
xx <- seq(minv,maxv,freqv)
xlabel<-expression(p)
prior <-  dunif(xx,0,1)
poverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
poverlap
