#============================================================
#============================================================
# Rcode for the book Parameter Redundancy and Identifiability
# By D.J. Cole
# Basic Occupancy Model
#============================================================
#============================================================

#===================================================
# Hessian Method for Basic Occupancy Model
# Section 4.1.1.1
#===================================================

# --------------------------------------------------------
# Hessian Method Functions
# --------------------------------------------------------
hessianmethod <- function(funfcn,pars,y,delta,epsilon,print=TRUE){
  # Applies the hessian method
  # funfcn - function which return negative loglikelihood
  # pars - parameter values at which hessian is evaluated
  # y - data to be passed into likelihood
  # delta - error used in calculating Hessian and cut-off
  # epsilon - cut-off for identifiable parameters
  # suggested values: delta = 0.00001, epsilon = 0.01
  
  # cut-off used delta*p, where p is no. pars
  cutoff <- delta*length(pars) 
  # Finds the hessian matrix:
  h <- do.call("hessian",list(funfcn,pars,y,delta)) 
  # Calculates eigenvalue:
  E <- eigen(h) 
  # Find standardised eigenvalues:
  standeigenvalues <- abs(E$values)/max(abs(E$values)) 
  # Find number of estimable parameters number of parameters:
  noestpars <- 0
  smalleig <- c( )
  for (i in 1:length(pars)) {
    if (standeigenvalues[i] >= cutoff) {
      noestpars <- noestpars + 1
    } 
    else {
      smalleig <- c(smalleig,i)
    }
  }
  
  # Find identifiable parameters if parameter redundant:
  identpars <- c( )
  if (min(standeigenvalues) < cutoff) {
     
     for (i in 1:length(pars)) {
        indent <- 1
        for (j in 1:length(smalleig)) {
           if (abs(E$vectors[i,smalleig[j]]) > epsilon) {
             indent <- 0
           }
        }
        if (indent==1) {
           identpars <- c(identpars,i)
        }
     }
  } 
  
  if (print) {
    # Prints whether model is parameter redundant or not
    if (min(standeigenvalues) < cutoff) {
      cat("model is non-identifiable or parameter redundant")
      cat("\n")
      if (is.null(identpars)) {
        cat('none of the original parameters are estimable')
      }
      else {
         cat('estimable parameters',identpars) 
      }
    } 
    else {
      cat("model is identifiable or not parameter redundant")
    }
    cat("\n")  
    cat('smallest standardised eigenvalue',min(standeigenvalues)) 
    cat("\n")  
    cat('number of estimable parameters',noestpars) 
  }
  result <- list(standeigenvalues=standeigenvalues,noestpars=noestpars,identpars=identpars,E=E)
  return(result)
}

hessian <- function(funfcn,x,y,delta){
  # function to calculate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}




#------------------------------------
# Finding Hessian matrix
#-------------------------------------
# Note to agree with Maple code need to look at log-likelihood where
# parameters are maximised on standard scale rather than logit scale (see below)

occlik2 <- function(pars,y){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  psi <- pars[1]
  p <- pars[2]
  #psi <- pars[1]
  #p <- pars[2]
  lik <- y[1]*log(p*psi)+y[2]*log(1-p*psi)
  -lik
}
options(digits=10) 
h=hessian(occlik2,c(0.75,(2/3)),y,0.00001)
h

# Finding the exact rank of the numerical Hessian matrix
install.packages("Matrix")
library(Matrix)
rankMatrix(h)

results <- hessianmethod(occlik2,c(0.75,(2/3)),y,0.00001,0.01,print=TRUE)
results


#---------------------------------------
# Testing choice of delta
#-------------------------------------


pars <-c(0.8,0.625)
exacth <- matrix(c(140.625,180,180,230.4),nrow=2, ncol=2,byrow = TRUE)

approxh <- hessian(occlik,pars,y,0.01)
sum(sqrt((exacth-approxh)^2))

approxh <- hessian(occlik,pars,y,0.001)
sum(sqrt((exacth-approxh)^2))

approxh <- hessian(occlik,pars,y,0.0001)
sum(sqrt((exacth-approxh)^2))

approxh <- hessian(occlik,pars,y,0.00001)
sum(sqrt((exacth-approxh)^2))

approxh <- hessian(occlik,pars,y,0.000001)
sum(sqrt((exacth-approxh)^2))

approxh <- hessian(occlik,pars,y,0.0000001)
sum(sqrt((exacth-approxh)^2))


# More typically we would use the following method to find parameter estimates, 
# which involves converting to a logit scale to ensure parameters
# stay constrained between zero and one

#-----------------------------------------------------------------
# Function for finding the likelihood of basic occupancy model
#-----------------------------------------------------------------
occlik <- function(pars,y){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  psi <- expo_fun(pars[1])
  p <- expo_fun(pars[2])
  #psi <- pars[1]
  #p <- pars[2]
  lik <- y[1]*log(p*psi)+y[2]*log(1-p*psi)
  -lik
}

# This function find the inverse logit of one or more values
expo_fun <- function(invec) 1/(1+exp(-invec))

# This function finds the logit of one of more values
logit_fun <- function(invec) log(invec/(1-invec))

#--------------------------------------------------------
# Evaluating the Hessian method
#--------------------------------------------------------

# Finding maximum likeliood estimates
y <- c(45,45) # the data
inpars <- logit(c(0.75,0.6667)) # Inital values for parameters
maxlik <- optim(inpars,occlik,y=y,method="L-BFGS-B",hessian=FALSE)
print(maxlik)
maxlikpar<-maxlik$par
pars <- expo_fun(maxlik$par)
print(pars)


results <- hessianmethod(occlik,maxlikpar,y,0.00001,0.01,print=TRUE)
results


#----------------------------------------------------------
# Simulation Method
# Section 4.1.2.1
#----------------------------------------------------------

#-----------------------------------------------------------------
# Function for finding the likelihood of basic occupancy model
#-----------------------------------------------------------------
occlik <- function(pars,y){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  psi <- expo_fun(pars[1])
  p <- expo_fun(pars[2])
  lik <- y[1]*log(p*psi)+y[2]*log(1-p*psi)
  -lik
}

psitrue <- 0.6
ptrue <- 0.4

N <- 3000
expdata <- N*c(ptrue*psitrue,1-ptrue*psitrue)

inpars <- logit(c(psitrue,ptrue)) # Inital values for parameters
maxlik <- optim(inpars,occlik,y=expdata,method="L-BFGS-B")
pars <- expo_fun(maxlik$par)
pars
bias <- sqrt((pars - c(psitrue,ptrue))^2)
bias
SE <- sqrt(diag(solve(hessian(occlik,maxlik$par,expdata,0.00001))))*pars*(1-pars)
CV <- SE/pars
CV

inpars <- logit(c(0.5,0.5)) # Inital values for parameters
maxlik <- optim(inpars,occlik,y=expdata,method="L-BFGS-B")
pars <- expo_fun(maxlik$par)
pars
bias <- sqrt((pars - c(psitrue,ptrue))^2)
bias
SE <- sqrt(diag(solve(hessian(occlik,maxlik$par,expdata,0.00001))))*pars*(1-pars)
CV <- SE/pars
CV

occlikre <- function(pars,y){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  beta <- expo_fun(pars[1])
  lik <- y[1]*log(beta)+y[2]*log(1-beta)
  -lik
}

betatrue=0.24

inpars <- logit(c(betatrue)) # Inital values for parameters
maxlik <- optim(inpars,occlikre,y=expdata,method="L-BFGS-B")
pars <- expo_fun(maxlik$par)
pars
bias <- sqrt((pars - c(betatrue))^2)
bias
SE <- sqrt(diag(solve(hessian(occlikre,maxlik$par,expdata,0.00001))))*pars*(1-pars)
CV <- SE/pars
CV

inpars <- logit(c(0.5)) # Inital values for parameters
maxlik <- optim(inpars,occlikre,y=expdata,method="L-BFGS-B")
pars <- expo_fun(maxlik$par)
pars
bias <- sqrt((pars - c(betatrue))^2)
bias
SE <- sqrt(diag(solve(hessian(occlikre,maxlik$par,expdata,0.00001))))*pars*(1-pars)
CV <- SE/pars
CV

