#===================================================
# Chapter 5 multinomial example in Subset profiling
#===================================================

# --------------------------------------------------------
# Hessian Method Functions
# --------------------------------------------------------
hessianmethod <- function(funfcn,pars,y,delta,epsilon,print=TRUE){
  # Applies the hessian method
  # funfcn - function which return negative loglikelihood
  # pars - parameter values at which hessian is evaluated
  # y - data to be passed into likelihood
  # delta - error used in calculating Hessian and cut-off
  # epsilon - cut-off for identifiable parameters
  # suggested values: delta = 0.00001, epsilon = 0.01
  
  # cut-off used delta*p, where p is no. pars
  cutoff <- delta*length(pars) 
  # Finds the hessian matrix:
  h <- do.call("hessian",list(funfcn,pars,y,delta)) 
  # Calculates eigenvalue:
  E <- eigen(h) 
  # Find standardised eigenvalues:
  standeigenvalues <- abs(E$values)/max(abs(E$values)) 
  # Find number of estimable parameters number of parameters:
  noestpars <- 0
  smalleig <- c( )
  for (i in 1:length(pars)) {
    if (standeigenvalues[i] >= cutoff) {
      noestpars <- noestpars + 1
    } 
    else {
      smalleig <- c(smalleig,i)
    }
  }
  
  # Find identifiable parameters if parameter redundant:
  identpars <- c( )
  if (min(standeigenvalues) < cutoff) {
    
    for (i in 1:length(pars)) {
      indent <- 1
      for (j in 1:length(smalleig)) {
        if (abs(E$vectors[i,smalleig[j]]) > epsilon) {
          indent <- 0
        }
      }
      if (indent==1) {
        identpars <- c(identpars,i)
      }
    }
  } 
  
  if (print) {
    # Prints whether model is parameter redundant or not
    if (min(standeigenvalues) < cutoff) {
      cat("model is non-identifiable or parameter redundant")
      cat("\n")
      if (is.null(identpars)) {
        cat('none of the original parameters are estimable')
      }
      else {
        cat('estimable parameters',identpars) 
      }
    } 
    else {
      cat("model is identifiable or not parameter redundant")
    }
    cat("\n")  
    cat('smallest standardised eigenvalue',min(standeigenvalues)) 
    cat("\n")  
    cat('number of estimable parameters',noestpars) 
  }
  result <- list(standeigenvalues=standeigenvalues,noestpars=noestpars,identpars=identpars,E=E)
  return(result)
}

hessian <- function(funfcn,x,y,delta){
  # function to calculate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}

#-----------------------------------------------------
# Log-Likelihood Profile Method Functions
#-----------------------------------------------------

profileplot <- function(funfcn,y,minpars,maxpars,freq,inpars,label) {
  # profileplot plots the log-likelihood profile for all parameters
  # funfcn needs to be a function that returns the negative log-likelihood
  # minpars and maxpars specify the minimum and maximum values for plots
  # freq specifies how often the log-likelihood profile is evaluated
  # inpars is a vector of inital values
  # label is a vector that specifies labels for the x-axis of the profile
  # plots, typically this would be the names of the parameters
  
  lv <- matrix(0,nrow=length(inpars),ncol=max((maxpars-minpars)/freq+1))
  parvs <- matrix(0,nrow=((length(inpars)-1)*length(inpars)),ncol=max((maxpars-minpars)/freq+1))
  for (j in 1:length(inpars) ) {
    fixparpos <- j
    av <- seq(minpars[fixparpos],maxpars[fixparpos], by=freq)
    
    for (i in 1:length(av)){
      fixpar <- c(av[i])
      if (fixparpos==1){
        inpars2 <- inpars[2:length(inpars)]
      }
      else if (fixparpos==length(inpars)) {
        inpars2 <- inpars[1:length(inpars)-1]
      }
      else {
        inpars2 <- c(inpars[1:(fixparpos-1)],inpars[(fixparpos+1):length(inpars)])
      }
      maxlik <- optim(par=inpars2,fn=profilelik,y=y,funfcn=funfcn,fixpar=fixpar,fixparpos=fixparpos,method="L-BFGS-B",hessian=TRUE)
      parvs[((j-1)*(length(inpars)-1)+1):((j-1)*(length(inpars)-1)+length(inpars)-1),i] <- maxlik$par
      lv[j,i] <- round(maxlik$value, digits = 2)
      
    }
    plot(av,-lv[j,1:length(av)],type = "l",ylab="log-lik",xlab=label[j])
  }
  return(list(lv=lv,parv=parvs))
}

profilelik <- function(par,y,funfcn,fixpar,fixparpos) {
  # profilelik returns the log-likelihood needed for a profile log-likelihood
  # Has the ability to fix more than one parameter (needed for subset profiling)
  # funfcn is the name of the function
  # pars are the parameters to be maximised
  # fixpar is the values of the fixed parameter
  # fixparpos is the position of the fixed parameter
  np <- length(par)
  nf <- length(fixpar)
  parsprev <- 0
  parscurr <- 0
  if (fixparpos[1]>1){
    parsprev <- 1
    parscurr <- fixparpos[1]-1
    z <- c(par[1:fixparpos[1]-1],fixpar[1])
  }
  else{
    z=c(fixpar[1])
  }
  if (nf>2) {
    for (i in 2:nf) {
      if (fixparpos[i]-fixparpos[i-1]>1) {
        parsprev <- parscurr;
        parscurr <- parscurr+fixparpos[i]-fixparpos[i-1]-1
        z <- c(z,par[parsprev+1:parscurr],fixpar[i])
      }
      else {
        z <-c(z,fixpar[i])
      }
    }
  }
  if (parscurr<np) {
    z <- c(z,par[parscurr+1:np])
  }
  
  y <- do.call("funfcn",list(z,y)) 
  return(y)
}

# -----------------------------------------------------------------------
# Logit and Inverse Logit (expit) functions
# -----------------------------------------------------------------------
expit <- function(xval) { 
  1/(1+exp(-xval))
}
logit <- function(xval) {
  log(xval/(1-xval))
}

# -----------------------------------------------------------------------
# Multinomial likelihood 
# -----------------------------------------------------------------------
multlik <- function(pars,y){
  # This function returns the negative log-likelihood for 
  # an occupancy model with perfect detection
  theta <- pars
  if (theta[1] > 1) {lik=-100000}
  else if (theta[1] < 0) {lik=-100000}
  if ((theta[2]+theta[3]) > 1) {lik=-100000}
  else if ((theta[2]+theta[3]) < 0) {lik=-100000}
  if ((theta[3]*theta[4]) > 1) {lik=-100000}
  else if ((theta[3]*theta[4]) < 0) {lik=-100000}
  if ((1-theta[1]-theta[2]-theta[3]-theta[3]*theta[4]) > 1) {lik=-100000}
  else if ((1-theta[1]-theta[2]-theta[3]-theta[3]*theta[4]) < 0) {lik=-100000}
  else {
     lik <- y[1]*log(theta[1])+y[2]*log(theta[2]+theta[3])+y[3]*log(theta[3]*theta[4])+y[4]*log(1-theta[1]-theta[2]-theta[3]-theta[3]*theta[4])
  }
  -lik
}

y <- c(20,30,10,40)
inpars <- c(0.2,0.1,0.2,0.5)
maxlik <- optim(inpars,multlik,y=y,method="L-BFGS-B",hessian=FALSE)
print(maxlik)
maxlikpar<-maxlik$par

results <- hessianmethod(multlik,maxlikpar,y,0.00001,0.01,print=TRUE)
results

