#==========================================================
#==========================================================
# R code for Book Parameter Redundancy and Identifiability
# by Diana J. Cole
# R code is for Ricker State-Space Model
# Section 8.2.1
#==========================================================
#==========================================================


# --------------------------------------------------------
# Hessian Method Functions
# --------------------------------------------------------
hessianmethod <- function(funfcn,pars,y,delta,print=TRUE){
  # Applies the hessian method
  # funfcn - function which return negative loglikelihood
  # pars - parameter values at which hessian is evaluated
  # y - data to be passed into likelihood
  # delta - error used in calculating Hessian and cutt-off
  # suggested value delta = 0.00001
  
  cutoff <- delta*length(pars) # cut-off used delta*p, where p is no. pars
  h <- do.call("hessian",list(funfcn,pars,y,delta)) # Finds hessian matrix
  E <- eigen(h) # Calculates eigenvalues
  standeigenvalues <- abs(E$values)/max(abs(E$values)) # find standardised eigenvalues
  # find number of estimable parameters
  # number of parameters with eigenvalues bellow the cutoff
  noestpars <- 0
  for (i in 1:length(pars)) {
    if (standeigenvalues[i] > cutoff) {
      noestpars <- noestpars + 1
    } 
  }
  if (print) {
     # Prints whether model is parameter redundant or not
     if (min(standeigenvalues) < cutoff) {
        cat("model is non-identifiable or parameter redundant")
     } 
     else {
        cat("model is identifiable or not parameter redundant")
     }
     cat("\n")  
     cat('smallest standardised eigenvalue',min(standeigenvalues)) # prints smallest eigenvalue
     cat("\n")  
     cat('number of estimable parameters',noestpars) # prints number of parameters
  }
  result <- list(standeigenvalues=standeigenvalues,noestpars=noestpars)
  return(result)
}

hessian <- function(funfcn,x,y,delta){
  # function to calcuate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}

#-----------------------------------------------------
# Log-Likelihood Profile Method Functions
#-----------------------------------------------------
profileplot <- function(funfcn,y,minpars,maxpars,freq,inpars,label) {
  # profileplot plots the likleihood profile for all parameters
  # funfcn needs to be a function that returns the negative log-likelkihood
  # minpars and maxpars specify the minmum and maximum values for plots
  # freq specifies how oftern the log-lik profile is evaluated
  # inpars is a vector of inital values
  # label is a vector that specifies labels for the x-axis of the profile
  # plots, typically this would be the names of the parameters
  
  lv <- matrix(0,nrow=length(inpars),ncol=max((maxpars-minpars)/freq+1))
  for (j in 1:length(inpars) ) {
    fixparpos <- j
    av <- seq(minpars[fixparpos],maxpars[fixparpos], by=freq)
    
    for (i in 1:length(av)){
      fixpar <- c(av[i])
      if (fixparpos==1){
        inpars2 <- inpars[2:length(inpars)]
      }
      else if (fixparpos==length(inpars)) {
        inpars2 <- inpars[1:length(inpars)-1]
      }
      else {
        inpars2 <- c(inpars[1:(fixparpos-1)],inpars[(fixparpos+1):length(inpars)])
      }
      maxlik <- optim(par=inpars2,fn=profilelik,y=y,funfcn=funfcn,fixpar=fixpar,fixparpos=fixparpos,method="L-BFGS-B",hessian=TRUE)
      lv[j,i] <- round(maxlik$value, digits = 2)
      
    }
    plot(av,-lv[j,1:length(av)],type = "l",ylab="log-lik",xlab=label[j])
  }
  return(lv)
}

profilelik <- function(par,y,funfcn,fixpar,fixparpos) {
  # PROFILELIK returns the likelihood needed for a profile likelihood
  # Has the ability to fix more than one parameter (needed for subset profiling)
  # funfcn is the name of the function
  # pars are the parameters to be maximised
  # fixpar is the values of the fixed parameter
  # fixparpos is the position of the fixed parameter
  np <- length(par)
  nf <- length(fixpar)
  parsprev <- 0
  parscurr <- 0
  if (fixparpos[1]>1){
    parsprev <- 1
    parscurr <- fixparpos[1]-1
    z <- c(par[1:fixparpos[1]-1],fixpar[1])
  }
  else{
    z=c(fixpar[1])
  }
  if (nf>2) {
    for (i in 2:nf) {
      if (fixparpos[i]-fixparpos[i-1]>1) {
        parsprev <- parscurr;
        parscurr <- parscurr+fixparpos[i]-fixparpos[i-1]-1
        z <- c(z,par[parsprev+1:parscurr],fixpar[i])
      }
      else {
        z <-c(z,fixpar[i])
      }
    }
  }
  if (parscurr<np) {
    z <- c(z,par[parscurr+1:np])
  }
  
  y <- do.call("funfcn",list(z,y)) 
  return(y)
}

# -----------------------------------------------------------------------
# Logit and Inverse Logit (expit) functions
# -----------------------------------------------------------------------
expit <- function(xval) { 
  1/(1+exp(-xval))
}
logit <- function(xval) {
  log(xval/(1-xval))
}


# --------------------------------------------------------------------------
# Likelihood function for Salmon example
# --------------------------------------------------------------------------
sallik <- function(pars,y){
  # This function returns the negative log-likelihood for the salmon
  # example using a normal approximation
  alpha <- exp(pars[1])
  beta <- exp(pars[2])
  n0 <- exp(pars[3])
  sigmasq <- 0.2
  
  a1<-n0
  P1 <- 0

  H <- sigmasq
  
  l <-0
  for (i in 1:length(y)) { 
    Q <- a1
    a <- alpha*a1*exp(-beta*a1)
    G <- alpha*(1-beta*a1)*exp(-beta*a1)
    P <- G*P1*G + Q
    v <- y[i]-a
    FF<-(P + H)
    a1 <- a + P * (1/FF)
    P1 <- P - P * (1/FF) * P

    l <- l - 1/2 * ( log(FF ) + v*(1/FF)*v)
  }

  return(-l)
}


#------------------------------------------------------------------
# Simulated Salmon data
#------------------------------------------------------------------
y <- c(104,217,226,466,764,781,903,1356,1189,1522,1334,1378,1146,1155,873,1918,1916,1445,1078,1573)


#------------------------------------------------------------------
# The Hessian method
#------------------------------------------------------------------

# Starting values for the maximum likelihood estimation
alphas <- 1.7
betas <- 0.0004
n0s <- 75
inpars <- c(log(alphas),log(betas),log(n0s))

# Finding maximum likelihood estimates:
maxlik <- optim(inpars,sallik,y=y,method="L-BFGS-B",hessian=TRUE)
pars <- c(exp(maxlik$par[1:3]))
pars

# Apply the hessian method using the function hessianmethod
# This needs as inputs: a likelihood function (sallik), the MLEs(maxlik$par), 
# the data (y), the precision value for Hessian calculation (0.00001)
results <- hessianmethod(sallik,maxlik$par,y,0.00001,print=TRUE)
results

#------------------------------------------------------------------
# The log-likelihood profile method
#------------------------------------------------------------------


# Specify minimum and maximum values for profile plots for all 3 parameters
# Note here the parameters are on the log scale
minpars <- c(0.1,-9,3) 
maxpars <- c(1,-7,5)
# Specifiy how often to evaluate profile
freq <- 0.01
# Specifiy initial parameters for maximisation algorithum
inpars <- c(0.5,-8,4)
# Give labels for x-axis of the 3 profile plots. 
# This is normally the parameter name
label <- c(expression(log(alpha)),expression(log(beta)),expression(log(n[0])))
# Produce the profile plots for log of parameter. The likelihood values are stored in lv.
lv <-profileplot(funfcn=sallik,y=y,minpars,maxpars,freq,inpars,label)

x <- exp(c(seq(minpars[1],maxpars[1],by = freq)))
nn <- length(x)
plot(x,-lv[1,1:nn],xlab=expression(alpha),ylab="log-lik",type = "l")

x <- exp(c(seq(minpars[2],maxpars[2],by = freq)))
nn <- length(x)
plot(x,-lv[2,1:nn],xlab=expression(beta),ylab="log-lik",type = "l")

x <- exp(c(seq(minpars[3],maxpars[3],by = freq)))
nn <- length(x)
plot(x,-lv[3,1:nn],xlab=expression(n[0]),ylab="log-lik",type = "l")
