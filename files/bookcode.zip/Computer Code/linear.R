#============================================================
#============================================================
# Rcode for the book Parameter Redundancy and Identifiability
# By D.J. Cole
# Linear Regression Model
#============================================================
#============================================================



#===================================================
# Hessian Method for linear regerssion model
# Section 4.1.1.3
#===================================================

# --------------------------------------------------------
# Hessian Method Functions
# --------------------------------------------------------
hessianmethod <- function(funfcn,pars,y,delta,epsilon,print=TRUE){
  # Applies the hessian method
  # funfcn - function which return negative loglikelihood
  # pars - parameter values at which hessian is evaluated
  # y - data to be passed into likelihood
  # delta - error used in calculating Hessian and cut-off
  # epsilon - cut-off for identifiable parameters
  # suggested values: delta = 0.00001, epsilon = 0.01
  
  # cut-off used delta*p, where p is no. pars
  cutoff <- delta*length(pars) 
  # Finds the hessian matrix:
  h <- do.call("hessian",list(funfcn,pars,y,delta)) 
  # Calculates eigenvalue:
  E <- eigen(h) 
  # Find standardised eigenvalues:
  standeigenvalues <- abs(E$values)/max(abs(E$values)) 
  # Find number of estimable parameters number of parameters:
  noestpars <- 0
  smalleig <- c( )
  for (i in 1:length(pars)) {
    if (standeigenvalues[i] >= cutoff) {
      noestpars <- noestpars + 1
    } 
    else {
      smalleig <- c(smalleig,i)
    }
  }
  
  # Find identifiable parameters if parameter redundant:
  identpars <- c( )
  if (min(standeigenvalues) < cutoff) {
    
    for (i in 1:length(pars)) {
      indent <- 1
      for (j in 1:length(smalleig)) {
        if (abs(E$vectors[i,smalleig[j]]) > epsilon) {
          indent <- 0
        }
      }
      if (indent==1) {
        identpars <- c(identpars,i)
      }
    }
  } 
  
  if (print) {
    # Prints whether model is parameter redundant or not
    if (min(standeigenvalues) < cutoff) {
      cat("model is non-identifiable or parameter redundant")
      cat("\n")
      if (is.null(identpars)) {
        cat('none of the original parameters are estimable')
      }
      else {
        cat('estimable parameters',identpars) 
      }
    } 
    else {
      cat("model is identifiable or not parameter redundant")
    }
    cat("\n")  
    cat('smallest standardised eigenvalue',min(standeigenvalues)) 
    cat("\n")  
    cat('number of estimable parameters',noestpars) 
  }
  result <- list(standeigenvalues=standeigenvalues,noestpars=noestpars,identpars=identpars,E=E)
  return(result)
}

hessian <- function(funfcn,x,y,delta){
  # function to calculate the hessian of funfcn at x 
  t <- length(x)
  h <- matrix(0, t, t)
  Dx <- delta*diag(t)
  for (i in 1:t) {
    for (j in 1:i) {
      h[i,j] <- (do.call("funfcn",list(x+Dx[i,]+Dx[j,],y))- do.call("funfcn",list(x+Dx[i,]-Dx[j,],y))- do.call("funfcn",list(x-Dx[i,]+Dx[j,],y)) + do.call("funfcn",list(x-Dx[i,]-Dx[j,],y)))/(4*delta^2)
      h[j,i] <- h[i,j]
    }
  }
  return(h)
}


#-----------------------------------------------------------------
# Function for finding the likelihood of the linear regression model
#-----------------------------------------------------------------
lmlik <- function(pars,data) {
  b0 <- pars[1]  
  b1 <- pars[2] 
  b2 <- pars[3] 
  sigma <- exp(pars[4])
  
  loglik <-0
  for (i in 1:length(data$y)) {
    likcont <- dnorm( data$y[i], mean = b0 + b1*data$x1[i] + b2*data$x2[i], sd = sigma)
    if (likcont==0){
      loglik <- loglik-100000
    }
    else {
      loglik<-loglik+log(likcont)
    }
  }
  return(-loglik)
}

#--------------------------------------------------------
# Evaluating the Hessian method
#--------------------------------------------------------

# the small data set
y <- c(5.8,5.9,7.4,7.5)
x1 <- c(3.2,3.2,4.5,4.5)
x2 <- c(1.1,1.1,2.2,2.2)
data <- list(y=y,x1=x1,x2=x2)
inpars <- c(3.51,0.38,1,log(0.05)) # Inital values for parameters
# Finding maximum likeliood estimates
maxlik <- optim(inpars,lmlik,data=data,method="L-BFGS-B",hessian=FALSE)
maxlikpar<-maxlik$par
# Prints maximum likelihood estimates (with sigma on standard scale)
print(c(maxlikpar[1:3],exp(maxlikpar[4])))

results <- hessianmethod(lmlik,maxlikpar,data,0.00001,0.01,print=TRUE)
results

# the simulated data set
# NB results will be different from the book, as different data is simulated
x1 <- runif(1000,0,5)
x2 <- runif(1000,0,2)
y <- 0.4 + 4.5*x1 + 2.2*x2 + rnorm(1000,0,1)
data <- list(y=y,x1=x1,x2=x2)
inpars <- c(0.5,5,2,log(1)) # Inital values for parameters
# Finding maximum likeliood estimates
maxlik <- optim(inpars,lmlik,data=data,method="L-BFGS-B",hessian=FALSE)
maxlikpar<-maxlik$par
# Prints maximum likelihood estimates (with sigma on standard scale)
print(c(maxlikpar[1:3],exp(maxlikpar[4])))

results <- hessianmethod(lmlik,maxlikpar,data,0.00001,0.01,print=TRUE)
results
