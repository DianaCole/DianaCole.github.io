#============================================================
#============================================================
# Rcode for the book Parameter Redundancy and Identifiability
# By D.J. Cole
# Mark-recovery Model - Chapter 6
#============================================================
#============================================================

# This code needs winbugs to be installed.

# Note if using Rsudio, you get the error 'Permission denied', you need to run Rstudio as 
# an administrator to get the code to work. (This depends on how your computer is set up
# and where winbugs is installed).

#------------------------------
# Accessing required libraries:
#-------------------------------
library(lattice)
library(coda)
library(R2WinBUGS)

#------------------------------
# Functions for Prior Overlap
#-------------------------------

overlap <- function(data,prior,minv,maxv,freqv,xlabel) {
  # overlap calculates the proportion overlap between the
  # prior and posterior using a kernel density to approximate
  # the posterior.
  # Also plots a graph of prior and posterior.
  # 'data' contains the posterior chain
  # 'prior' contains a vector of prior values evaluated at same interval
  # as 'minv', 'maxv' and 'freqv' values given
  
  k1 <- 0.9 # Controls the smoothness of the kernel
  
  x <- seq(minv,maxv,freqv)
  nn <- length(x)
  fK <- c(rep(0,nn))
  
  overlap<-0
  for (i in 1:nn) {
    fK[i]<-kernel(x[i],data,k1)
    if (fK[i]<prior[i]){
      overlap<-overlap+fK[i]*freqv
    }
    else {
      overlap=overlap+prior[i]*freqv
    }
  }
  
  plot(x,fK,type = "l",ylab="f",xlab=xlabel)
  lines(x,prior,lty=2)  
  return(overlap)
}


kernel <- function(y,data,k1) {
  # kernel calculates a kernel density estimate for a sample in 'data'.
  #   'y' is the value at which we want the kernel estimate.
  #   'k1' can be chosen to vary the amount of smoothing.
  #   Calls the function delta.
  
  n <- length(data)
  h <- k1*min(sd(data),IQR(data)/1.34)/n^0.2	
  
  z <- 0
  for (i in 1:n ) {
    z<-z+delta((y-data[i])/h)
  }				            
  z<-z/(n*h);
}

delta <- function(u) {
  # delta calculates a normal kernel
  y <-(exp(-u*u/2))/sqrt(2*pi);
}

#--------------------------------------------
# Code to run WinBUGS
#---------------------------------------------

#Specify the directory where WinBUGS is located
bugs.dir <- c("C:/Program Files (x86)/WinBUGS14")  

# The data:
m <- matrix(c(120,12,10,8,8,842,
              0,120,12,10,6,852,
              0,0,120,12,10,858,
              0,0,0,120,12,868,
              0,0,0,0,120,880),
            nrow=5,ncol=6,byrow=TRUE)


# Winbugs model, stored in caprec.bug:
sink("caprec.bug")
cat("
model {
# Define the recovery likelihood
    for (t in 1 : T){
    m[t, 1 : T+1] ~ dmulti(p[t,], rel[t])}
    # Calculate the no. of birds released each year
    for (t in 1 : T){
    rel[t] <- sum(m[t, ])}
    # Below gives code for uniform priors, can be updated for other priors
    phi1 ~ dunif(0,1)
    phi2 ~ dunif(0,1)
    lambda1 ~ dunif(0,1)
    lambda2 ~ dunif(0,1)
    # Calculate the cell probabilities for the recovery table, last column probabilty of never been seen again
    p[1,1]<-(1-phi1)*lambda1
    p[1,2] <- phi1*(1-phi2)*lambda2
    p[1,3] <- phi1*phi2*(1-phi2)*lambda2
    p[1,4] <- phi1*phi2*phi2*(1-phi2)*lambda2
    p[1,5] <- phi1*phi2*phi2*phi2*(1-phi2)*lambda2
    p[1,6]<- 1-p[1,1]-p[1,2]-p[1,3]-p[1,4]-p[1,5]
    p[2,1]<-0
    p[2,2]<-(1-phi1)*lambda1
    p[2,3] <- phi1*(1-phi2)*lambda2
    p[2,4] <- phi1*phi2*(1-phi2)*lambda2
    p[2,5] <- phi1*phi2*phi2*(1-phi2)*lambda2
    p[2,6]<- 1-p[2,2]-p[2,3]-p[2,4]-p[2,5]
    p[3,1]<-0
    p[3,2]<-0
    p[3,3]<-(1-phi1)*lambda1
    p[3,4] <- phi1*(1-phi2)*lambda2
    p[3,5] <- phi1*phi2*(1-phi2)*lambda2
    p[3,6]<- 1-p[3,3]-p[3,4]-p[3,5]
    p[4,1]<-0
    p[4,2]<-0
    p[4,3]<-0
    p[4,4]<-(1-phi1)*lambda1
    p[4,5] <- phi1*(1-phi2)*lambda2
    p[4,6]<- 1-p[4,4]-p[4,5]
    p[5,1]<-0
    p[5,2]<-0
    p[5,3]<-0
    p[5,4]<-0
    p[5,5]<-(1-phi1)*lambda1
    p[5,6]<-1-p[5,5]
    }
",fill=TRUE)
sink()




# Parameters to be monitored (NB phi2 is phi_a and lambda2 is lambda_a)
parameters <- c("phi1","phi2","lambda1","lambda2")

# Assigning MCMC update values, number of iterations, burnin etc
chain <- 1
iter <- 200000
burn	<- 100000
thin <- 1

# The data for WinBUGS
data.or <-list(m=m,T=5)

#The initial values for WinBUGS
init.nt <- function(){list(phi=0.6,phi2=0.8,lambda1=0.3,lambda2=0.1)}


# Performs MCMC in WinBUG
intro.out <- bugs(data.or,inits=init.nt,model.file = "caprec.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)

# Puts the samples into a useable format in R
# In particular results$mu is a vector of simulated mu values etc 
codaintro <- read.bugs(intro.out)
results <- do.call(rbind.data.frame, codaintro)

# Summarises the posterior, producing posterior means, standard deviations etc
summary(codaintro)

par(mfrow=c(2,2))

# The following code finds the prior and posterior overlap:
# The posterior sample is stored in post
post<-results$phi1
# The minimum (minv), maximum (maxv) and frequency (freqv) used in the 
# kernel density
# A smaller freqv will improve accuracy but take longer to evalulate
minv<- 0
maxv<- 1
freqv<-0.01
# Setting up prior, which must match minv, maxv and freqv used above.
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,0,1) # Vector of prior values - the prior evaluated at x
xlabel<-expression(phi[1]) # label for x-axis in graph
# Calls the function overlap to find proportion overlap between prior
# and posterior, and plots figure
phi1overlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phi1overlap

post<-results$phi2
minv<- 0
maxv<- 1
freqv<-0.01
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,0,1) # Vector of prior values - the prior evaluated at x
xlabel<-expression(phi[a]) # label for x-axis in graph
phiaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phiaoverlap

post<-results$lambda1
minv<- 0
maxv<- 1
freqv<-0.01
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,0,1) # Vector of prior values - the prior evaluated at x
xlabel<-expression(lambda[1]) # label for x-axis in graph
lambda1overlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
lambda1overlap

post<-results$lambda2
minv<- 0
maxv<- 1
freqv<-0.01
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,0,1) # Vector of prior values - the prior evaluated at x
xlabel<-expression(lambda[a]) # label for x-axis in graph
lambdaaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
lambdaaoverlap

