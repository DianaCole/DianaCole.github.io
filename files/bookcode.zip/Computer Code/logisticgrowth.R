#============================================================
#============================================================
# Rcode for the book Parameter Redundancy and Identifiability
# By D.J. Cole
# Logistic growth curve Model - Chapter 6
#============================================================
#============================================================


# This code needs winbugs to be installed.

# Note if using Rsudio, you get the error 'Permission denied', you need to run Rstudio as 
# an administrator to get the code to work. (This depends on how your computer is set up
# and where winbugs is installed).

#------------------------------
# Accessing required libraries:
#-------------------------------
library(lattice)
library(coda)
library(R2WinBUGS)

#------------------------------
# Functions for Prior Overlap
#-------------------------------

overlap <- function(data,prior,minv,maxv,freqv,xlabel) {
  # overlap calculates the proportion overlap between the
  # prior and posterior using a kernel density to approximate
  # the posterior.
  # Also plots a graph of prior and posterior.
  # 'data' contains the posterior chain
  # 'prior' contains a vector of prior values evaluated at same interval
  # as 'minv', 'maxv' and 'freqv' values given
  
  k1 <- 0.9 # Controls the smoothness of the kernel
  
  x <- seq(minv,maxv,freqv)
  nn <- length(x)
  fK <- c(rep(0,nn))
  
  overlap<-0
  for (i in 1:nn) {
    fK[i]<-kernel(x[i],data,k1)
    if (fK[i]<prior[i]){
      overlap<-overlap+fK[i]*freqv
    }
    else {
      overlap=overlap+prior[i]*freqv
    }
  }
  
  plot(x,fK,type = "l",ylab="f",xlab=xlabel)
  lines(x,prior,lty=2)  
  return(overlap)
}


kernel <- function(y,data,k1) {
  # kernel calculates a kernel density estimate for a sample in 'data'.
  #   'y' is the value at which we want the kernel estimate.
  #   'k1' can be chosen to vary the amount of smoothing.
  #   Calls the function delta.
  
  n <- length(data)
  h <- k1*min(sd(data),IQR(data)/1.34)/n^0.2	
  
  z <- 0
  for (i in 1:n ) {
    z<-z+delta((y-data[i])/h)
  }				            
  z<-z/(n*h);
}

delta <- function(u) {
  # delta calculates a normal kernel
  y <-(exp(-u*u/2))/sqrt(2*pi);
}

#--------------------------------------------
# Code to run WinBUGS
#---------------------------------------------

#Specify the directory where WinBUGS is located
bugs.dir <- c("C:/Program Files (x86)/WinBUGS14")  

# y is the vector of data, n is the sample size, and xi represent the columns of X
y <- c(31,21,12,44,27,8,41,33,24,48,38,18)
n <- length(y)
x2 <- c(1,1,1,1,1,1,0,0,0,0,0,0)
x3 <- c(0,0,0,0,0,0,1,1,1,1,1,1) 
x4 <- c(1,1,1,0,0,0,1,1,1,0,0,0)
x5 <- c(0,0,0,1,1,1,0,0,0,1,1,1)
x6 <- c(-1,0,1,-1,0,1,-1,0,1,-1,0,1)
x7 <- c(-1,0,1,0,0,0,-1,0,1,0,0,0)
x8 <- c(0,0,0,-1,0,1,0,0,0,-1,0,1)
NN <- 50

# Winbugs model, stored in grow.bug:
sink("grow.bug")
cat("
model { 
for(j in 1 :n) {
    logit(p[j])<-mu+alphaD1*x2[j]+alphaD2*x3[j]+alphaT1*x4[j]+alphaT2*x5[j]+beta0*x6[j]+beta1*x7[j]+beta2*x8[j]
    y[j]~ dbin(p[j],NN) 
    }
    # Shown below for uniform priors only. Code needs to be changed for alternative priors
    mu ~ dunif(-5,5)
    alphaD1~ dunif(-5,5) 
    alphaD2~ dunif(-5,5) 
    alphaT1~ dunif(-5,5) 
    alphaT2~ dunif(-5,5) 
    beta0~dunif(-5,5)
    beta1~dunif(-5,5)
    beta2~dunif(-5,5)
    }
",fill=TRUE)
sink()




# Parameters to be monitored
parameters <- c("mu","alphaD1","alphaD2","alphaT1","alphaT2","beta0","beta1","beta2")

# Assigning MCMC update values, number of iterations, burnin etc
chain <- 1 
iter <- 20000
burn	<- 10000
thin <- 1

# The data for WinBUGS
data.or <-list(n=n,NN=NN,y=y,x2=x2,x3=x3,x4=x4,x5=x5,x6=x6,x7=x7,x8=x8)

#The initial values for WinBUGS
init.nt <- function(){list(mu=0.5,alphaD1=-0.5,alphaD2=0.5,alphaT1=-0.3,alphaT2=0.2,beta0=-1,beta1=0.2,beta2=-0.8)}

# Performs MCMC in WinBUG
intro.out <- bugs(data.or,inits=init.nt,model.file = "grow.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)

# Puts the samples into a useable format in R
# In particular results$mu is a vector of simulated mu values etc 
codaintro <- read.bugs(intro.out)
results <- do.call(rbind.data.frame, codaintro)

# Summarises the posterior, producing posterior means, standard deviations etc
summary(codaintro)

# The following code finds the prior and posterior overlap:
# The posterior sample is stored in post
post<-results$alphaD1
# The minimum (minv), maximum (maxv) and frequency (freqv) used in the 
# kernel density
# A smaller freqv will improve accuracy but take longer to evalulate
minv<- -5
maxv<- 5
freqv<-0.01
# Setting up prior, which must match minv, maxv and freqv used above.
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,-5,5) # Vector of prior values - the prior evaluated at x
xlabel<-expression(alpha[D,1]) # label for x-axis in graph
# Calls the function overlap to find proportion overlap between prior
# and posterior, and plots figure
thetaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
thetaoverlap

# repeat code for other parameters changing post<-results$alphaD1

#--------------------------------------------------------------------------------
# Data Cloning Code:
#--------------------------------------------------------------------------------

# K is number of clones. When K = 1 this is equivalent to just using original data
K <- 1
# Cloned data
y2 <- K*y

# The data for WinBUGS
data.or <-list(n=n,N=50,y=y2,x2=x2,x3=x3,x4=x4,x5=x5,x6=x6,x7=x7,x8=x8)

#The initial values for WinBUGS
init.nt <- function(){list(mu=0.5,alphaD1=-0.5,alphaD2=0.5,alphaT1=-0.3,alphaT2=0.2,beta0=-1,beta1=0.2,beta2=-0.8)}

# Performs MCMC in WinBUG
intro.out <- bugs(data.or,inits=init.nt,model.file = "grow.bug",
                   parameters=parameters, n.chains =chain, n.iter =iter,
                   n.burnin=burn,n.thin=thin,debug=F, 
                   bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)

# Puts the samples into a useable format in R
# In particular results$mu is a vector of simulated mu values etc 
codaintro <- read.bugs(intro.out)
results <- do.call(rbind.data.frame, codaintro)

# Summarises the posterior, producing posterior means, standard deviations etc
summary(codaintro)

# svari is a vector set up to store the standardised posterior variance
# for each parameter
# The variance is found and then divided through by the variance for K = 1
# (The first value will always be 1.)
svar1<-c(var(results$phi1)/var(results$phi1))
svar2<-c(var(results$phia)/var(results$phia))
svar3<-c(var(results$rho)/var(results$rho))
print(c(var(results$phi1),var(results$phia),var(results$rho)))

# The code below is similar to above but repeats for different number of clones
# Here we use K = 20, 40, 60 and 100
# The standised variance is stored in svari (and then displayed on screen)
# This code will take a few minutes to run
for (kk in 1:5) {
  ptm2 <- proc.time()
   K<- kk*20
   y2 <- matrix(rep(y,K),nrow=K,ncol=T,byrow=T)
   N1 <- c(rep(400,T))
   N12 <- matrix(rep(N1,K),nrow=K,ncol=T,byrow=T)
   Na2 <- y2
   data.or <-list(T=T,y=y2,K=K)
   init.nt <- function(){list(phi1=0.6,phia=0.8,rho=1.5,N1=N12,Na=Na2)}
   intro.out2 <- bugs(data.or,inits=init.nt,model.file = "intro.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)
   codaintro2 <- read.bugs(intro.out2)
   results2 <- do.call(rbind.data.frame, codaintro2)
   svar1<-c(svar1,var(results2$phi1)/var(results$phi1))
   svar2<-c(svar2,var(results2$phia)/var(results$phia))
   svar3<-c(svar3,var(results2$rho)/var(results$rho))
   print(c(var(results2$phi1),var(results2$phia),var(results2$rho)))
   proc.time() - ptm2
   print(ptm2)
}
svar1
svar2
svar3

# Lastly the standardised variance is plotted on a graph:
KK=c(1,20,40,60,80,100)
plot(KK,1/KK,type="l",xlab="K",ylab="Standardised Variance")
points(KK,svar1,pch=0)
points(KK,svar2,pch=1)
points(KK,svar3,pch=2)
legend("right",c('1/K',expression(phi[1]),expression(phi[a]),expression(rho)), lty=c(1,0,0,0),pch = c(NA,0,1,2))