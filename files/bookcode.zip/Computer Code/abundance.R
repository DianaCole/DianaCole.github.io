# Accessing required libraries:
library(lattice)
library(coda)
library(R2WinBUGS)

#Specify the directory where WinBUGS is located
bugs.dir <- c("C:/Program Files (x86)/WinBUGS14")  

# Lapwing data
# y is the vector of data and T is the sample size.
y <- c(1092,1100, 1234, 1461, 1570, 1820,1391,1508,1541,1631)
T <- length(y)


# Winbugs model, stored in intro.bug:
sink("intro.bug")
cat("
model	{
	  # priors 
    phi1 ~ dunif(0,1)
    phia ~ dunif(0,1)
    rho ~ dunif(0,10)
    
    # sigma is fixed at 6
    sigy <- 6
    tauy <-1/sigy

    for (k in 1:K){ # Additional loop for data cloning
       N1[k,1] ~ dnorm(400,0.001)
       Na[k,1] ~ dnorm(1000,0.001)  
    }
    
    for (k in 1:K){ # Additional loop for data cloning
       for(t in 2:T){ 
          mean1[k,t] <- rho*phi1*Na[k,t-1]
          meana[k,t] <- phia*(N1[k,t-1]+Na[k,t-1])
          tau1[k,t] <- 1/(Na[k,t-1]*rho*phi1)
          taua[k,t] <- 1/((N1[k,t-1]+Na[k,t-1])*phia*(1-phia))
          N1[k,t] ~ dnorm(mean1[k,t],tau1[k,t])
          Na[k,t] ~ dnorm(meana[k,t],taua[k,t])
          y[k,t] ~ dnorm(Na[k,t],tauy)  
       }
    }     
}
",fill=TRUE)
sink()

#------------------------------
# Functions for Prior Overlap
#-------------------------------

overlap <- function(data,prior,minv,maxv,freqv,xlabel) {
  # overlap calculates the proportion overlap between the
  # prior and posterior using a kernel density to approximate
  # the posterior.
  # Also plots a graph of prior and posterior.
  # 'data' contains the posterior chain
  # 'prior' contains a vector of prior values evaluated at same interval
  # as 'minv', 'maxv' and 'freqv' values given
  
  k1 <- 0.9 # Controls the smoothness of the kernel
  
  x <- seq(minv,maxv,freqv)
  nn <- length(x)
  fK <- c(rep(0,nn))
  
  overlap<-0
  for (i in 1:nn) {
    fK[i]<-kernel(x[i],data,k1)
    if (fK[i]<prior[i]){
      overlap<-overlap+fK[i]*freqv
    }
    else {
      overlap=overlap+prior[i]*freqv
    }
  }
  
  plot(x,fK,type = "l",ylab="f",xlab=xlabel)
  lines(x,prior,lty=2)  
  return(overlap)
}


kernel <- function(y,data,k1) {
  # kernel calculates a kernel density estimate for a sample in 'data'.
  #   'y' is the value at which we want the kernel estimate.
  #   'k1' can be chosen to vary the amount of smoothing.
  #   Calls the function delta.
  
  n <- length(data)
  h <- k1*min(sd(data),IQR(data)/1.34)/n^0.2	
  
  z <- 0
  for (i in 1:n ) {
    z<-z+delta((y-data[i])/h)
  }				            
  z<-z/(n*h);
}

delta <- function(u) {
  # delta calculates a normal kernel
  y <-(exp(-u*u/2))/sqrt(2*pi);
}

# Parameters to be monitored
parameters <- c("phi1","phia","rho")

# Assigning MCMC update values, number of iterations, burnin etc
chain <- 1 
iter <- 20000
burn	<- 10000
thin <- 1

# K is number of clones. When K = 1 this is equivalent to just using original data
K <- 1
# Data is converted to a matrix:
y2 <- matrix(rep(y,K),nrow=K,ncol=T,byrow=T)

# The data for WinBUGS
data.or <-list(T=T,y=y2,K=K)

#The initial values for WinBUGS
N1 <- c(rep(400,T))
N12 <- matrix(rep(N1,K),nrow=K,ncol=T,byrow=T)
Na2 <- y2
init.nt <- function(){list(phi1=0.6,phia=0.8,rho=1.5,N1=N12,Na=Na2)}

# Performs MCMC in WinBUGS
# This code will take a few minutes to run
ptm2 <- proc.time()
intro.out <- bugs(data.or,inits=init.nt,model.file = "intro.bug",
                   parameters=parameters, n.chains =chain, n.iter =iter,
                   n.burnin=burn,n.thin=thin,debug=F, 
                   bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)
proc.time() - ptm2
print(ptm2)

# Puts the samples into a useable format in R
# In particular results$phi1 is a vector of simulated phi1 values etc 
codaintro <- read.bugs(intro.out)
results <- do.call(rbind.data.frame, codaintro)

# Summarises the posterior, producing posterior means, standard deviations etc
#summary(codaintro, quantiles = c(0.025, 0.25, 0.5, 0.75, 0.975))

# svari is a vector set up to store the standardised posterior variance
# for each parameter
# The variance is found and then divided through by the variance for K = 1
# (The first value will always be 1.)
svar1<-c(var(results$phi1)/var(results$phi1))
svar2<-c(var(results$phia)/var(results$phia))
svar3<-c(var(results$rho)/var(results$rho))
print(c(var(results$phi1),var(results$phia),var(results$rho)))

# The code below is similar to above but repeats for different number of clones
# Here we use K = 20, 40, 60 and 100
# The standised variance is stored in svari (and then displayed on screen)
# This code will take a few minutes to run
for (kk in 1:5) {
  ptm2 <- proc.time()
   K<- kk*20
   y2 <- matrix(rep(y,K),nrow=K,ncol=T,byrow=T)
   N1 <- c(rep(400,T))
   N12 <- matrix(rep(N1,K),nrow=K,ncol=T,byrow=T)
   Na2 <- y2
   data.or <-list(T=T,y=y2,K=K)
   init.nt <- function(){list(phi1=0.6,phia=0.8,rho=1.5,N1=N12,Na=Na2)}
   intro.out2 <- bugs(data.or,inits=init.nt,model.file = "intro.bug",
                  parameters=parameters, n.chains =chain, n.iter =iter,
                  n.burnin=burn,n.thin=thin,debug=F, 
                  bugs.directory =bugs.dir,clearWD=TRUE,codaPkg=TRUE)
   codaintro2 <- read.bugs(intro.out2)
   results2 <- do.call(rbind.data.frame, codaintro2)
   svar1<-c(svar1,var(results2$phi1)/var(results$phi1))
   svar2<-c(svar2,var(results2$phia)/var(results$phia))
   svar3<-c(svar3,var(results2$rho)/var(results$rho))
   print(c(var(results2$phi1),var(results2$phia),var(results2$rho)))
   proc.time() - ptm2
   print(ptm2)
}
svar1
svar2
svar3

# Lastly the standardised variance is plotted on a graph:
KK=c(1,20,40,60,80,100)
plot(KK,1/KK,type="l",xlab="K",ylab="Standardised Variance")
points(KK,svar1,pch=0)
points(KK,svar2,pch=1)
points(KK,svar3,pch=2)
legend("right",c('1/K',expression(phi[1]),expression(phi[a]),expression(rho)), lty=c(1,0,0,0),pch = c(NA,0,1,2))


# The following code finds the prior and posterior overlap:
# The posterior sample is stored in post
post<-results$phi1
# The minimum (minv), maximum (maxv) and frequency (freqv) used in the 
# kernel density
# A smaller freqv will improve accuracy but take longer to evalulate
minv<-0  
maxv<-1
freqv<-0.01
# Setting up prior, which must match minv, maxv and freqv used above.
xx <- seq(minv,maxv,freqv) # Vector of x values used for prior
prior <-  dunif(xx,0,1) # Vector of prior values - the prior evaluated at x
xlabel<-expression(phi[1]) # label for x-axis in graph
# Calls the function overlap to find proportion overlap between prior
# and posterior, and plots figure
phi1overlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phi1overlap

# Repeats above but for parameter phia
post<-results$phia
inv<-0  
maxv<-1
freqv<-0.01
xx <- seq(minv,maxv,freqv) 
prior <-  dunif(xx,0,1) 
xlabel<-expression(phi[a])
phiaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
phiaoverlap

# Repeats above but for parameter rho
post<-results$rho
minv<-0
maxv<-10
freqv<-0.01
xx <- seq(minv,maxv,freqv)
xlabel<-expression(rho)
prior <-  dunif(xx,0,10)
rhoaoverlap<-overlap(post,prior,minv,maxv,freqv,xlabel)
rhoaoverlap

